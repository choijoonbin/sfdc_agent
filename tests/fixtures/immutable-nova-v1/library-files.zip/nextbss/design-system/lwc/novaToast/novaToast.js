import { LightningElement, api } from 'lwc';
import { createNotificationTimer } from 'c/novaNotificationUtils';
import { getFeedbackIcon } from 'c/novaFeedbackIcons';
export default class NovaToast extends LightningElement {
  @api
  open = false;
  @api
  message = '';
  @api
  heading = '';
  @api
  tone = 'neutral';
  @api
  duration = 4000;
  @api
  placement = 'inline';
  _timer;
  _timerKey = '';
  _closeRequested = false;
  _hovered = false;
  _focused = false;
  get notificationRole() {
    return ['error', 'negative'].includes(this.tone) ? 'alert' : 'status';
  }
  get icon() {
    return false
      ? undefined
      : getFeedbackIcon(this.tone === 'negative' ? 'error' : this.tone);
  }
  renderedCallback() {
    if (!this._timer)
      this._timer = createNotificationTimer(() => this.requestClose('timeout'));
    const key = this.open
      ? `${this.message}|${this.heading}|${this.tone}|${this.duration}`
      : '';
    if (key !== this._timerKey) {
      this._timer.clear();
      this._timerKey = key;
      this._closeRequested = false;
      if (key) {
        this._timer.start(this.duration);
        if (this._hovered || this._focused) this._timer.pause();
      } else {
        this._hovered = false;
        this._focused = false;
      }
    }
  }
  disconnectedCallback() {
    this._timer?.dispose();
    this._timer = undefined;
    this._timerKey = '';
  }
  requestClose(reason) {
    if (this._closeRequested || !this.open) return;
    this._closeRequested = true;
    this._timer?.clear();
    this.dispatchEvent(
      new CustomEvent('request_close', {
        detail: {
          reason,
        },
      }),
    );
  }
  pauseTimer(event) {
    if (event?.type === 'mouseenter') this._hovered = true;
    if (event?.type === 'focusin') this._focused = true;
    this._timer?.pause();
  }
  resumeTimer(event) {
    if (event?.type === 'mouseleave') this._hovered = false;
    if (event?.type === 'focusout') {
      if (event.currentTarget.contains(event.relatedTarget)) return;
      this._focused = false;
    }
    if (!this._closeRequested && !this._hovered && !this._focused)
      this._timer?.resume();
  }
}
