export function numberValue(value, fallback = 0) {
  return value !== '' && value != null && Number.isFinite(Number(value))
    ? Number(value)
    : fallback;
}
export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
export function stepValue(value, delta, min, max) {
  return Number(clamp(Number(value) + Number(delta), min, max).toFixed(10));
}
export function numberError(value, min, max, step) {
  if (value === '' || !Number.isFinite(Number(value)))
    return '숫자를 입력해 주세요.';
  const n = Number(value);
  if (n < min) return `${min} 이상을 입력해 주세요.`;
  if (n > max) return `${max} 이하를 입력해 주세요.`;
  const ratio = (n - (Number.isFinite(min) ? min : 0)) / step;
  if (Math.abs(ratio - Math.round(ratio)) > 1e-7)
    return `${step} 단위에 맞는 값을 입력해 주세요.`;
  return '';
}
