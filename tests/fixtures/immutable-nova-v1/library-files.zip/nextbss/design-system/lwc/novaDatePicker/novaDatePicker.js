import { LightningElement, api } from 'lwc';
import {
  calendarDate,
  isoDate,
  datePart,
  timePart,
  dateAllowed,
  monthDays,
} from 'c/novaDateUtils';
import { emit } from 'c/novaControlUtils';
const weekdays = [
  {
    short: '일',
    name: '일요일',
  },
  {
    short: '월',
    name: '월요일',
  },
  {
    short: '화',
    name: '화요일',
  },
  {
    short: '수',
    name: '수요일',
  },
  {
    short: '목',
    name: '목요일',
  },
  {
    short: '금',
    name: '금요일',
  },
  {
    short: '토',
    name: '토요일',
  },
];
export default class NovaDatePicker extends LightningElement {
  _value = '';
  @api
  get value() {
    return this._value;
  }
  set value(value) {
    const next = value ?? '';
    if (next === this._value) return;
    this._value = next;
    if (this.isConnected) this.resetDraft();
  }
  _endValue = '';
  @api
  get endValue() {
    return this._endValue;
  }
  set endValue(value) {
    const next = value ?? '';
    if (next === this._endValue) return;
    this._endValue = next;
    if (this.isConnected) this.resetDraft();
  }
  @api
  range = false;
  @api
  withTime = false;
  @api
  min = '';
  @api
  max = '';
  @api
  disabled = false;
  @api
  label = '날짜 선택';
  draftStart = '';
  draftEnd = '';
  draftStartTime = '00:00:00';
  draftEndTime = '00:00:00';
  selectingEnd = false;
  viewYear = new Date().getFullYear();
  viewMonth = new Date().getMonth();
  focusedDate = '';
  focusPending = false;
  connectedCallback() {
    this.resetDraft();
  }
  @api
  resetDraft() {
    this.draftStart = datePart(this.value);
    this.draftEnd = datePart(this.endValue);
    this.draftStartTime = timePart(this.value);
    this.draftEndTime = timePart(this.endValue);
    this.selectingEnd = false;
    const initial = this.draftStart || this.clampDate(isoDate(new Date()));
    this.setView(initial);
    this.focusedDate = initial;
  }
  clampDate(value) {
    const min = datePart(this.min),
      max = datePart(this.max);
    return min && value < min ? min : max && value > max ? max : value;
  }
  setView(value) {
    const date = datePart(value);
    if (date) {
      this.viewYear = Number(date.slice(0, 4));
      this.viewMonth = Number(date.slice(5, 7)) - 1;
    }
  }
  get weekdays() {
    return weekdays;
  }
  get shortcuts() {
    return this.range
      ? [
          {
            id: 'today',
            label: '오늘',
          },
          {
            id: 'week',
            label: '최근 7일',
          },
          {
            id: 'month',
            label: '최근 30일',
          },
          {
            id: 'current-month',
            label: '이번 달',
          },
        ]
      : [
          {
            id: 'today',
            label: '오늘',
          },
        ];
  }
  get days() {
    return monthDays(
      this.viewYear,
      this.viewMonth,
      this.draftStart,
      this.draftEnd,
      this.min,
      this.max,
    ).map((day) => ({
      ...day,
      disabled: this.disabled || day.disabled,
      tabindex: day.value === this.focusedDate ? '0' : '-1',
    }));
  }
  get years() {
    const first = Math.max(1, this.viewYear - 8);
    return Array.from(
      {
        length: Math.min(17, 10000 - first),
      },
      (_, i) => ({
        value: first + i,
        selected: first + i === this.viewYear,
      }),
    );
  }
  get months() {
    return Array.from(
      {
        length: 12,
      },
      (_, i) => ({
        value: i,
        label: `${i + 1}월`,
        selected: i === this.viewMonth,
      }),
    );
  }
  get monthLabel() {
    return `${this.viewYear}년 ${this.viewMonth + 1}월`;
  }
  get invalidRange() {
    return (
      this.range &&
      this.draftStart &&
      this.draftEnd &&
      (this.draftStart > this.draftEnd ||
        (this.withTime &&
          this.draftStart === this.draftEnd &&
          this.draftStartTime > this.draftEndTime))
    );
  }
  get cannotApply() {
    return (
      this.disabled ||
      !dateAllowed(this.draftStart, this.min, this.max) ||
      (this.range && !dateAllowed(this.draftEnd, this.min, this.max)) ||
      this.invalidRange
    );
  }
  @api
  focus() {
    this.focusPending = true;
    this.requestUpdateFocus();
  }
  requestUpdateFocus() {
    Promise.resolve().then(() => {
      const target =
        this.template.querySelector(
          `[data-date="${this.focusedDate}"]:not(:disabled)`,
        ) ||
        this.template.querySelector('.day:not(:disabled)') ||
        this.template.querySelector('button');
      target?.focus();
      this.focusPending = false;
    });
  }
  renderedCallback() {
    if (this.focusPending) this.requestUpdateFocus();
  }
  changeMonth(event) {
    if (this.disabled) return;
    const n = event.currentTarget.dataset.direction === 'next' ? 1 : -1;
    this.moveMonth(n);
  }
  moveMonth(offset) {
    const date = calendarDate(this.viewYear, this.viewMonth + offset, 1);
    if (date.getFullYear() < 1 || date.getFullYear() > 9999) return;
    this.setView(isoDate(date));
    const day = Math.min(
      Number(this.focusedDate.slice(-2)) || 1,
      calendarDate(this.viewYear, this.viewMonth + 1, 0).getDate(),
    );
    this.focusedDate = this.clampDate(
      isoDate(calendarDate(this.viewYear, this.viewMonth, day)),
    );
  }
  yearChange(event) {
    event.stopPropagation();
    this.viewYear = Number(event.target.value);
    this.focusedDate = this.clampDate(
      isoDate(calendarDate(this.viewYear, this.viewMonth, 1)),
    );
  }
  monthChange(event) {
    event.stopPropagation();
    this.viewMonth = Number(event.target.value);
    this.focusedDate = this.clampDate(
      isoDate(calendarDate(this.viewYear, this.viewMonth, 1)),
    );
  }
  choose(event) {
    const value = event.currentTarget.dataset.date;
    if (this.disabled || !dateAllowed(value, this.min, this.max)) return;
    this.select(value);
  }
  select(value) {
    if (!this.range || !this.selectingEnd) {
      this.draftStart = value;
      this.draftEnd = '';
      this.selectingEnd = this.range;
    } else {
      this.draftEnd = value;
      if (this.draftEnd < this.draftStart)
        [this.draftStart, this.draftEnd] = [this.draftEnd, this.draftStart];
      this.selectingEnd = false;
    }
    this.focusedDate = value;
  }
  handleShortcut(event) {
    if (this.disabled) return;
    const id = event.currentTarget.dataset.value;
    const today = new Date();
    const start = new Date(today);
    if (id === 'week') start.setDate(today.getDate() - 6);
    if (id === 'month') start.setDate(today.getDate() - 29);
    if (id === 'current-month') start.setDate(1);
    this.draftStart = this.clampDate(isoDate(start));
    this.draftEnd = this.range ? this.clampDate(isoDate(today)) : '';
    this.focusedDate = this.draftStart;
    this.setView(this.draftStart);
    this.selectingEnd = false;
  }
  timeChange(event) {
    event.stopPropagation();
    if (this.disabled) return;
    const time = timePart(` ${event.target.value}`);
    if (event.currentTarget.dataset.endpoint === 'end')
      this.draftEndTime = time;
    else this.draftStartTime = time;
  }
  keydown(event) {
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      this.cancel();
      return;
    }
    if (!event.target.dataset?.date || this.disabled) return;
    const source = datePart(event.target.dataset.date);
    if (!source) return;
    const date = calendarDate(
      Number(source.slice(0, 4)),
      Number(source.slice(5, 7)) - 1,
      Number(source.slice(8)),
    );
    let next = '';
    const increments = {
      ArrowLeft: -1,
      ArrowRight: 1,
      ArrowUp: -7,
      ArrowDown: 7,
    };
    if (Object.hasOwn(increments, event.key)) {
      date.setDate(date.getDate() + increments[event.key]);
      next = isoDate(date);
    } else if (event.key === 'Home') {
      date.setDate(date.getDate() - date.getDay());
      next = isoDate(date);
    } else if (event.key === 'End') {
      date.setDate(date.getDate() + 6 - date.getDay());
      next = isoDate(date);
    } else if (event.key === 'PageDown' || event.key === 'PageUp') {
      this.moveMonth(
        (event.key === 'PageDown' ? 1 : -1) * (event.shiftKey ? 12 : 1),
      );
      next = this.focusedDate;
    }
    if (next) {
      event.preventDefault();
      this.focusedDate = this.clampDate(next);
      this.setView(this.focusedDate);
      this.focusPending = true;
    }
  }
  cancel() {
    emit(this, 'request_close', {
      reason: 'cancel',
    });
  }
  apply() {
    if (this.cannotApply) return;
    const format = (date, time) => date + (this.withTime ? `T${time}` : '');
    const detail = {
      value: format(this.draftStart, this.draftStartTime),
    };
    if (this.range) detail.endValue = format(this.draftEnd, this.draftEndTime);
    emit(this, 'change', detail);
    emit(this, 'request_close', {
      reason: 'apply',
    });
  }
}
