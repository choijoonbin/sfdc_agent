import { LightningElement, api } from 'lwc';
import { getFeedbackIcon } from 'c/novaFeedbackIcons';
export default class NovaBadge extends LightningElement {
  @api
  label = '';
  @api
  variant = 'text';
  @api
  tone = 'neutral';
  @api
  count;
  @api
  accessibleLabel;
  @api
  libraryAppearance = '';
  get verifiedTableLabel() {
    return this.libraryAppearance === 'verified-table-label';
  }
  get type() {
    return ['text', 'dot', 'dot-only', 'indicator', 'count', 'status'].includes(
      this.variant,
    )
      ? this.variant
      : 'text';
  }
  get dot() {
    return this.type === 'dot' || this.type === 'dot-only';
  }
  get indicatorOnly() {
    return (
      this.type === 'dot-only' ||
      (this.type === 'indicator' && !this.label && this.count == null)
    );
  }
  get badgeRole() {
    return this.indicatorOnly ? 'img' : undefined;
  }
  get badgeLabel() {
    return this.indicatorOnly
      ? this.accessibleLabel || this.label || '알림 있음'
      : this.accessibleLabel;
  }
  get displayValue() {
    return ['count', 'indicator'].includes(this.type) && this.count != null
      ? String(this.count)
      : this.label;
  }
  get icon() {
    return getFeedbackIcon(
      this.type === 'status'
        ? 'badgeStatus'
        : this.type === 'text' && this.tone === 'highlight'
          ? 'trophy'
          : '',
    );
  }
  get metric() {
    return this.type === 'status' && this.count != null
      ? String(this.count)
      : undefined;
  }
}
