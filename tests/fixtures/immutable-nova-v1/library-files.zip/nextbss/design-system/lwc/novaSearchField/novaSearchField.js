import { LightningElement, api } from 'lwc';
import { optionsOf, nextEnabled } from 'c/novaSelectionUtils';
import {
  stateClass,
  isDisabled,
  isReadOnly,
  emit,
  safeFieldStyle,
} from 'c/novaControlUtils';
import { fieldIcons, buttonIcons } from 'c/novaControlIcons';
export default class NovaSearchField extends LightningElement {
  @api
  label = '';
  @api
  accessibleLabel = '';
  @api
  hideLabel = false;
  @api
  size = 'large';
  @api
  state = '';
  @api
  disabled = false;
  @api
  readOnly = false;
  @api
  required = false;
  @api
  placeholder = '';
  @api
  helperText = '';
  @api
  errorMessage = '';
  @api
  maxLength;
  @api
  widthBehavior = '';
  @api
  libraryAppearance = '';
  @api
  fieldBackground = '';
  @api
  fieldBorderColor = '';
  @api
  helperIndicator = false;
  @api
  name = '';
  @api
  value = '';
  @api
  suggestions = [];
  @api
  options = [];
  @api
  actionLabel = '조회';
  @api
  variant = '';
  @api
  loading = false;
  opened = false;
  active = -1;
  composing = false;
  get rootClass() {
    return stateClass(this);
  }
  get labelClass() {
    return this.hideLabel ? 'label hidden-label' : 'label';
  }
  get disabledValue() {
    return isDisabled(this);
  }
  get readonlyValue() {
    return isReadOnly(this);
  }
  get locked() {
    return this.disabledValue || this.readonlyValue;
  }
  get requiredValue() {
    return this.required || this.state === 'required';
  }
  get invalid() {
    return !!this.errorMessage || this.state === 'error';
  }
  get description() {
    return this.errorMessage || this.helperText;
  }
  get describedBy() {
    return this.description ? 'helper' : undefined;
  }
  get inputLabel() {
    return this.accessibleLabel || this.label || '입력';
  }
  get sourceStyle() {
    return safeFieldStyle(this);
  }
  handleInput(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'input', {
        value: event.target.value,
      });
  }
  handleChange(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'change', {
        value: event.target.value,
      });
  }
  @api
  focus() {
    this.template.querySelector('input,textarea')?.focus();
  }
  @api
  checkValidity() {
    const field = this.template.querySelector('input,textarea');
    field?.setCustomValidity(this.errorMessage || '');
    return field?.checkValidity() ?? true;
  }
  @api
  reportValidity() {
    const field = this.template.querySelector('input,textarea');
    field?.setCustomValidity(this.errorMessage || '');
    return field?.reportValidity() ?? true;
  }
  get overall() {
    return ['overall', 'overall-search', 'recommend'].includes(this.variant);
  }
  get searchClass() {
    return this.overall ? 'search overall' : 'search';
  }
  get wrapClass() {
    return this.overall ? 'search-wrap overall-wrap' : 'search-wrap';
  }
  get searchIcon() {
    return this.size === 'large'
      ? fieldIcons['field-search']
      : buttonIcons.search;
  }
  get recommendIcon() {
    return fieldIcons.hashtag;
  }
  get rows() {
    const query = String(this.value).toLocaleLowerCase();
    return optionsOf(this.suggestions?.length ? this.suggestions : this.options)
      .filter((row) => row.label.toLocaleLowerCase().includes(query))
      .map((row, index) => ({
        ...row,
        index,
        id: `suggestion-${index}`,
        active: this.active === index,
      }));
  }
  get hasSuggestions() {
    return this.rows.length > 0;
  }
  get expanded() {
    return this.opened && !this.locked && this.hasSuggestions;
  }
  get controls() {
    return this.expanded ? 'suggestions' : undefined;
  }
  get activeId() {
    return this.expanded && this.active >= 0
      ? `suggestion-${this.active}`
      : undefined;
  }
  get searchName() {
    return this.accessibleLabel || this.label || '검색';
  }
  handleInput(event) {
    event.stopPropagation();
    if (this.locked) return;
    this.active = -1;
    this.opened = true;
    emit(this, 'input', {
      value: event.target.value,
    });
  }
  handleChange(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'change', {
        value: event.target.value,
      });
  }
  composeStart() {
    this.composing = true;
  }
  composeEnd() {
    this.composing = false;
  }
  search() {
    if (this.locked || this.loading || this.composing || !this.reportValidity())
      return;
    this.opened = false;
    emit(this, 'search', {
      value: this.template.querySelector('input')?.value ?? this.value,
    });
  }
  toggleSuggestions() {
    if (!this.locked) this.opened = !this.expanded;
  }
  focusOut(event) {
    if (!event.currentTarget.contains(event.relatedTarget)) this.opened = false;
  }
  retainFocus(event) {
    event.preventDefault();
  }
  choose(event) {
    this.select(Number(event.currentTarget.dataset.index));
  }
  select(index) {
    const row = this.rows[index];
    if (!row || row.disabled || this.locked) return;
    this.opened = false;
    emit(this, 'input', {
      value: row.label,
    });
    emit(this, 'change', {
      value: row.label,
    });
    emit(this, 'selection_change', {
      value: row.value,
      label: row.label,
    });
    this.focus();
  }
  keydown(event) {
    if (
      this.locked ||
      event.isComposing ||
      this.composing ||
      event.keyCode === 229
    )
      return;
    if (event.key === 'Escape') {
      if (this.expanded) {
        event.preventDefault();
        event.stopPropagation();
        this.opened = false;
      }
      return;
    }
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      if (!this.rows.length) return;
      event.preventDefault();
      this.opened = true;
      this.active = nextEnabled(
        this.rows,
        this.active,
        event.key === 'ArrowDown' ? 1 : -1,
      );
    } else if (event.key === 'Enter') {
      event.preventDefault();
      if (this.expanded && this.active >= 0) this.select(this.active);
      else this.search();
    } else if (event.key === 'Tab') this.opened = false;
  }
}
