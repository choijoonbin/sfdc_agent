import { api, LightningElement } from 'lwc';
import { asText } from 'c/novaNavigationUtils';

const plotWidth = 400;
const plotHeight = 156;
const optionalNumber = (value) =>
  value === undefined || value === null || value === ''
    ? undefined
    : Number.isFinite(Number(value))
      ? Number(value)
      : undefined;

export default class NovaGraph extends LightningElement {
  @api renderer = 'line';
  @api series = [];
  @api referenceLine;
  @api referenceText = '';
  @api max;
  @api metric;
  @api highlightIndex;
  @api pointText = '';
  @api targetPercent;
  @api unit = '';
  @api label = '';
  @api description = '';
  @api emptyMessage = '데이터가 없습니다.';

  get unsupported() {
    return this.renderer !== 'line';
  }
  get graphLabel() {
    return this.label || '데이터 그래프';
  }
  get target() {
    return optionalNumber(this.targetPercent);
  }
  get meter() {
    return this.target !== undefined;
  }
  get percent() {
    return Math.max(0, Math.min(100, this.target ?? 0));
  }
  get meterStyle() {
    return `inline-size:${this.percent}%;`;
  }
  get meterLabel() {
    return asText(this.metric) || `${this.percent}%`;
  }
  get data() {
    return Array.isArray(this.series)
      ? this.series.flatMap((point) => {
          const value = optionalNumber(point?.value);
          return typeof point?.label === 'string' && value !== undefined
            ? [{ label: point.label, value }]
            : [];
        })
      : [];
  }
  get reference() {
    return optionalNumber(this.referenceLine);
  }
  get hasReferenceLine() {
    return this.reference !== undefined;
  }
  get range() {
    const values = this.data.map((point) => point.value);
    if (this.hasReferenceLine) values.push(this.reference);
    return {
      min: Math.min(0, ...values),
      max: Math.max(1, ...values, optionalNumber(this.max) ?? 0),
    };
  }
  get points() {
    const data = this.data;
    const { min, max } = this.range;
    const width = plotWidth / Math.max(1, data.length);
    return data.map((point, index) => ({
      ...point,
      id: `point-${index}`,
      x: width * index + width / 2,
      y: (plotHeight * (max - point.value)) / (max - min),
    }));
  }
  get hasPoints() {
    return !this.unsupported && this.points.length > 0;
  }
  get linePoints() {
    return this.points.map(({ x, y }) => `${x},${y}`).join(' ');
  }
  get baseline() {
    return (plotHeight * this.range.max) / (this.range.max - this.range.min);
  }
  get referenceY() {
    return (
      (plotHeight * (this.range.max - this.reference)) /
      (this.range.max - this.range.min)
    );
  }
  get highlightedPoint() {
    return this.points[Number(this.highlightIndex)];
  }
  get pointLabelPosition() {
    const { x = 0, y = 0 } = this.highlightedPoint || {};
    return `translate(${Math.max(2, Math.min(254, x - 72))} ${y - 37})`;
  }
}
