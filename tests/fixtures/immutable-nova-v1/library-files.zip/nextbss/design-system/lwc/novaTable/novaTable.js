import { api, LightningElement } from 'lwc';
import { asText, nextId, emit } from 'c/novaNavigationUtils';
import {
  columnsOf,
  rowsOf,
  sortRows,
  toggleRowSelection,
} from 'c/novaTableUtils';
export default class NovaTable extends LightningElement {
  @api
  columns = [];
  @api
  rows = [];
  @api
  rowKey = 'id';
  @api
  selectedIds = [];
  @api
  expandedIds = [];
  @api
  sort;
  @api
  sortMode = 'manual';
  @api
  selection = 'none';
  @api
  variant = 'horizontal';
  @api
  disabled = false;
  @api
  loading = false;
  @api
  errorMessage = '';
  @api
  emptyMessage = '데이터가 없습니다.';
  @api
  label = '데이터 표';
  radioName = nextId('nova-table');
  get headings() {
    return columnsOf(this.columns).map((column) => ({
      ...column,
      widthStyle: Number.isFinite(Number(column.width)) && Number(column.width) > 0 ? `width:${Number(column.width)}px` : undefined,
      sort: column.sortable
        ? this.sort?.columnId === column.id
          ? this.sort.direction
          : 'none'
        : null,
      mark:
        this.sort?.columnId === column.id
          ? this.sort.direction === 'descending'
            ? '↓'
            : '↑'
          : '↕',
    }));
  }
  get entries() {
    const cols = this.headings;
    const source = rowsOf(this.rows, cols, this.rowKey);
    const sorted =
      this.sortMode === 'local' ? sortRows(source, cols, this.sort) : source;
    const selected = new Set(
        Array.isArray(this.selectedIds) ? this.selectedIds : [],
      ),
      expanded = new Set(
        Array.isArray(this.expandedIds) ? this.expandedIds : [],
      );
    return sorted.map((row) => ({
      ...row,
      disabled: this.disabled || row.disabled,
      selected: selected.has(row.id),
      expanded: expanded.has(row.id),
      hasDetails: !!asText(row.details),
      label: `${row.id} 선택`,
      className: `table-row ${row.state} ${selected.has(row.id) ? 'selected' : ''}`,
    }));
  }
  get hasRows() {
    return !this.loading && !this.errorMessage && this.entries.length > 0;
  }
  get vertical() {
    return ['vertical', 'large'].includes(this.variant);
  }
  get details() {
    return this.entries[0]?.cells || [];
  }
  get multiple() {
    return this.selection === 'multiple';
  }
  get single() {
    return this.selection === 'single';
  }
  get selectable() {
    return this.multiple || this.single;
  }
  get columnCount() {
    return Math.max(1, this.headings.length + Number(this.selectable));
  }
  get allSelected() {
    const rows = this.entries.filter((x) => !x.disabled);
    return rows.length > 0 && rows.every((x) => x.selected);
  }
  get allDisabled() {
    return !this.entries.some((x) => !x.disabled);
  }
  get statusMessage() {
    return this.loading
      ? '불러오는 중입니다.'
      : this.errorMessage || this.emptyMessage;
  }
  renderedCallback() {
    const all = this.template.querySelector('[data-select-all]');
    if (all)
      all.indeterminate =
        !this.allSelected &&
        this.entries.some((x) => !x.disabled && x.selected);
  }
  handleSort(event) {
    if (this.disabled) return;
    const columnId = event.currentTarget.dataset.column;
    const column = this.headings.find((x) => x.id === columnId);
    if (!column?.sortable) return;
    emit(this, 'sort_change', {
      columnId,
      direction:
        this.sort?.columnId === columnId && this.sort.direction === 'ascending'
          ? 'descending'
          : 'ascending',
    });
  }
  selectRow(event) {
    const row = this.entries.find((x) => x.id === event.target.dataset.id);
    if (!row || row.disabled) return;
    emit(this, 'selection_change', {
      ids: toggleRowSelection(
        this.selectedIds,
        row.id,
        event.target.checked,
        this.single,
      ),
    });
  }
  selectAll(event) {
    if (this.disabled) return;
    const enabled = this.entries.filter((x) => !x.disabled).map((x) => x.id),
      ids = new Set(Array.isArray(this.selectedIds) ? this.selectedIds : []);
    for (const id of enabled) {
      if (event.target.checked) ids.add(id);
      else ids.delete(id);
    }
    emit(this, 'selection_change', {
      ids: [...ids],
    });
  }
  expand(event) {
    const row = this.entries.find(
      (x) => x.id === event.currentTarget.dataset.id,
    );
    if (row && !row.disabled)
      emit(this, 'row_toggle', {
        id: row.id,
        expanded: !row.expanded,
      });
  }
  cellAction(event) {
    if (this.disabled) return;
    const row = this.entries.find(
      (x) => x.id === event.currentTarget.dataset.row,
    );
    if (row && !row.disabled)
      emit(this, 'row_action', {
        id: row.id,
        columnId: event.currentTarget.dataset.column,
      });
  }
  cellChange(event) {
    const row = this.entries.find(
      (x) => x.id === event.currentTarget.dataset.row,
    );
    if (row && !row.disabled)
      emit(this, 'cell_change', {
        id: row.id,
        columnId: event.currentTarget.dataset.column,
        value: event.target.value,
      });
  }
}
