import { api, LightningElement } from 'lwc';
import { nextId } from 'c/novaNavigationUtils';
export default class NovaTabPanel extends LightningElement {
  _value = '';
  _label = '';
  _disabled = false;
  _count;
  _active = false;
  _trigger;
  _pending = false;
  panelId = nextId('nova-tab-panel');
  @api
  get value() {
    return this._value;
  }
  set value(value) {
    if (value !== this._value) {
      this._value = value;
      this.notify();
    }
  }
  @api
  get label() {
    return this._label;
  }
  set label(value) {
    if (value !== this._label) {
      this._label = value;
      this.notify();
    }
  }
  @api
  get disabled() {
    return this._disabled;
  }
  set disabled(value) {
    const next = value === true || value === '' || value === 'true';
    if (next !== this._disabled) {
      this._disabled = next;
      this.notify();
    }
  }
  @api
  get count() {
    return this._count;
  }
  set count(value) {
    if (value !== this._count) {
      this._count = value;
      this.notify();
    }
  }
  connectedCallback() {
    this.notify();
  }
  notify() {
    if (!this.isConnected || this._pending) return;
    this._pending = true;
    queueMicrotask(() => {
      this._pending = false;
      if (this.isConnected)
        this.dispatchEvent(
          new CustomEvent('panel_change', {
            bubbles: true,
            composed: false,
          }),
        );
    });
  }
  @api
  setTabState(active, trigger) {
    this._active = active;
    this._trigger = trigger;
    this.syncHost();
  }
  renderedCallback() {
    this.syncHost();
  }
  syncHost() {
    const host = this.hostElement;
    if (!host) return;
    if (!host.id) host.id = this.panelId;
    host.hidden = !this._active;
    host.setAttribute('role', 'tabpanel');
    host.setAttribute('tabindex', '0');
    host.setAttribute('aria-label', this.label || '탭 내용');
    if (this._trigger && 'ariaLabelledByElements' in host)
      host.ariaLabelledByElements = [this._trigger];
  }
}
