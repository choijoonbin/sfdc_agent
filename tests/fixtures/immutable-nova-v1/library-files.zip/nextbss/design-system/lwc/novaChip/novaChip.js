import { LightningElement, api } from 'lwc';
import { getFeedbackIcon } from 'c/novaFeedbackIcons';
export default class NovaChip extends LightningElement {
  @api
  label = '';
  @api
  value;
  @api
  variant = 'basic';
  @api
  size = 'default';
  @api
  state = '';
  @api
  selected = false;
  @api
  disabled = false;
  @api
  removable = false;
  @api
  interactive = false;
  @api
  count;
  get selectable() {
    return this.interactive || this.variant === 'filter';
  }
  get canRemove() {
    return this.removable || this.variant === 'remove';
  }
  get locked() {
    return this.disabled || this.state === 'disabled';
  }
  get chipState() {
    return this.locked ? 'disabled' : this.selected ? 'selected' : this.state === 'hovered' ? 'hovered' : 'default';
  }
  get chipInteractive() {
    return !this.locked && (this.selectable || this.canRemove);
  }
  get displayCount() {
    return ['count', 'filter', 'remove'].includes(this.variant) && Number.isSafeInteger(this.count) && this.count >= 0
      ? this.count > 999
        ? '999+'
        : String(this.count)
      : undefined;
  }
  get icon() {
    return this.variant === 'count' ? getFeedbackIcon('won') : undefined;
  }
  get removeLabel() {
    return `${this.label || '항목'} 삭제`;
  }
  get closePath() {
    return getFeedbackIcon('close').paths[0].d;
  }
  @api
  focus() {
    this.template.querySelector('button')?.focus();
  }
  handleSelect() {
    if (!this.locked)
      this.dispatchEvent(
        new CustomEvent('change', {
          detail: {
            value: this.value,
            selected: !this.selected,
          },
        }),
      );
  }
  handleRemove(event) {
    event.stopPropagation();
    if (!this.locked)
      this.dispatchEvent(
        new CustomEvent('remove', {
          detail: {
            value: this.value,
          },
        }),
      );
  }
}
