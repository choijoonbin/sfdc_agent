import { LightningElement, api } from 'lwc';
import { stateClass, isDisabled, isReadOnly, emit } from 'c/novaControlUtils';
import { numberValue, stepValue, numberError } from 'c/novaNumberUtils';
export default class NovaStepper extends LightningElement {
  @api
  label = '수량';
  _value = 0;
  @api
  get value() {
    return this._value;
  }
  set value(value) {
    this._value = value ?? 0;
    this.draft = undefined;
    this.localError = '';
  }
  @api
  min = 0;
  @api
  max;
  @api
  step = 1;
  @api
  variant = '';
  @api
  size = 'large';
  @api
  state = '';
  @api
  disabled = false;
  @api
  readOnly = false;
  @api
  helperText = '';
  @api
  errorMessage = '';
  draft;
  localError = '';
  get rootClass() {
    return stateClass(this);
  }
  get locked() {
    return isDisabled(this) || isReadOnly(this);
  }
  get disabledValue() {
    return isDisabled(this);
  }
  get readonlyValue() {
    return isReadOnly(this);
  }
  get lower() {
    return numberValue(this.min, 0);
  }
  get upper() {
    return Math.max(this.lower, numberValue(this.max, Infinity));
  }
  get inputMax() {
    return Number.isFinite(this.upper) ? this.upper : undefined;
  }
  get increment() {
    return Math.max(Number.EPSILON, numberValue(this.step, 1));
  }
  get numeric() {
    return numberValue(this.value, this.lower);
  }
  get display() {
    return this.draft ?? this.value;
  }
  get valueStyle() {
    return this.variant === 'contained'
      ? undefined
      : `--nova-stepper-digits:${Math.max(1, String(this.display ?? '').length)}`;
  }
  get atMin() {
    return this.locked || this.numeric <= this.lower;
  }
  get atMax() {
    return this.locked || this.numeric >= this.upper;
  }
  get stepperClass() {
    return this.variant === 'contained' ? 'stepper contained' : 'stepper';
  }
  get description() {
    return this.localError || this.errorMessage || this.helperText;
  }
  get describedBy() {
    return this.description ? 'helper' : undefined;
  }
  get invalid() {
    return !!(this.localError || this.errorMessage) || this.state === 'error';
  }
  adjust(event) {
    if (this.locked) return;
    const direction = event.currentTarget.dataset.direction === 'up' ? 1 : -1;
    this.commit(
      stepValue(
        this.numeric,
        direction * this.increment,
        this.lower,
        this.upper,
      ),
    );
  }
  commit(value) {
    this.draft = undefined;
    this.localError = '';
    emit(this, 'change', {
      value,
    });
  }
  handleInput(event) {
    event.stopPropagation();
    if (!this.locked) {
      this.draft = event.target.value;
      this.localError = '';
    }
  }
  handleChange(event) {
    event.stopPropagation();
    if (this.locked) return;
    this.localError = numberError(
      event.target.value,
      this.lower,
      this.upper,
      this.increment,
    );
    if (!this.localError) this.commit(Number(event.target.value));
  }
  keydown(event) {
    if (this.locked) return;
    if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
      event.preventDefault();
      this.commit(
        stepValue(
          this.numeric,
          (event.key === 'ArrowUp' ? 1 : -1) * this.increment,
          this.lower,
          this.upper,
        ),
      );
    }
  }
  @api
  focus() {
    this.template.querySelector('input')?.focus();
  }
  @api
  checkValidity() {
    return (
      !numberError(this.value, this.lower, this.upper, this.increment) &&
      !this.errorMessage
    );
  }
  @api
  reportValidity() {
    this.localError = numberError(
      this.draft ?? this.value,
      this.lower,
      this.upper,
      this.increment,
    );
    return !this.localError && !this.errorMessage;
  }
}
