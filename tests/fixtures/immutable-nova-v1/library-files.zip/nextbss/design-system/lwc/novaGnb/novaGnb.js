import { api, LightningElement } from 'lwc';
import {
  normalizeItems,
  emit,
  nextIndex,
  modifiedClick,
} from 'c/novaNavigationUtils';
export default class NovaGnb extends LightningElement {
  @api
  sessions = [];
  @api
  customerItems = [];
  @api
  workItems = [];
  @api
  activeSessionId = '';
  @api
  activeItemId = '';
  @api
  customerCount = 0;
  @api
  showCustomerSelector = false;
  @api
  addCustomer = false;
  @api
  addCustomerDisabled = false;
  @api
  addCustomerLabel = '고객 연결';
  @api
  disabled = false;
  @api
  label = '전체 메뉴';
  menuKey = '';
  pinned = false;
  recent = {};
  offset = 0;
  menuTop = 86;
  clipStart = 'false';
  clipEnd = 'false';
  focusMenu = false;
  leaveTimer;
  resizeObserver;
  observedScroll;
  get customers() {
    return normalizeItems(this.customerItems, 'customer');
  }
  get sessionsView() {
    return normalizeItems(this.sessions, 'session').map((item) => {
      const active = item.id === this.activeSessionId;
      const selected =
        this.activeItemId && active ? this.activeItemId : this.recent[item.id];
      const task =
        item.children.find((x) => x.id === selected && !x.disabled) ||
        item.children.find((x) => !x.disabled);
      return {
        ...item,
        active,
        disabled: this.disabled || item.disabled,
        href: this.disabled || item.disabled ? undefined : item.href,
        current: active ? 'page' : null,
        expanded:
          !active && item.hasChildren
            ? String(this.menuKey === item.key)
            : null,
        detail: active
          ? ''
          : this.recent[item.id]
            ? task?.label
            : item.detail || task?.label,
        children: item.children.map((child) => ({
          ...child,
          disabled: this.disabled || child.disabled,
          current: child.id === task?.id ? 'page' : null,
        })),
      };
    });
  }
  get work() {
    return normalizeItems(this.workItems, 'work').map((item) => ({
      ...item,
      active: item.id === this.activeSessionId,
      disabled: this.disabled || item.disabled,
      href: this.disabled || item.disabled ? undefined : item.href,
      current: item.id === this.activeSessionId ? 'page' : null,
    }));
  }
  get hasSelector() {
    return (
      this.showCustomerSelector ||
      this.customerCount > 0 ||
      this.addCustomer ||
      this.customers.length > 0
    );
  }
  get count() {
    return Number.isFinite(Number(this.customerCount))
      ? Math.max(0, Number(this.customerCount))
      : this.sessionsView.length;
  }
  get canAdd() {
    return !this.disabled && !this.addCustomerDisabled;
  }
  get addDisabled() {
    return !this.canAdd;
  }
  get customerExpanded() {
    return String(this.menuKey === 'customers');
  }
  get hasMenu() {
    return Boolean(this.menuKey);
  }
  get menuGroup() {
    return this.menuKey === 'customers'
      ? null
      : this.sessionsView.find((x) => x.key === this.menuKey);
  }
  get menuItems() {
    return (
      this.menuKey === 'customers'
        ? this.customers
        : this.menuGroup?.children || []
    ).map((x) => ({
      ...x,
      disabled: this.disabled || x.disabled,
    }));
  }
  get menuTitle() {
    return this.menuKey === 'customers'
      ? '상담 고객'
      : `${this.menuGroup?.label || ''} 업무 목록`;
  }
  get menuStyle() {
    return `inset-inline-start:${this.offset}px;inset-block-start:${this.menuTop}px`;
  }
  connectedCallback() {
    this.outside = (event) => {
      if (this.pinned && !event.composedPath().includes(this.hostElement))
        this.close();
    };
    window.addEventListener('pointerdown', this.outside);
  }
  disconnectedCallback() {
    window.removeEventListener('pointerdown', this.outside);
    this.resizeObserver?.disconnect();
    clearTimeout(this.leaveTimer);
  }
  renderedCallback() {
    const scroll = this.template.querySelector('.gnb-scroll');
    if (scroll && scroll !== this.observedScroll) {
      this.resizeObserver?.disconnect();
      this.observedScroll = scroll;
      if (typeof ResizeObserver === 'function') {
        this.resizeObserver = new ResizeObserver(() => {
          this.syncOverflow(scroll);
          this.position();
        });
        this.resizeObserver.observe(scroll);
        if (scroll.firstElementChild)
          this.resizeObserver.observe(scroll.firstElementChild);
      }
    }
    if (scroll) this.syncOverflow(scroll);
    this.position();
    if (this.focusMenu) {
      this.focusMenu = false;
      this.template.querySelector('.gnb-menu-item:not([disabled])')?.focus();
    }
  }
  syncOverflow(scroll) {
    const left = Math.abs(scroll.scrollLeft);
    const a = String(left > 1),
      b = String(left + scroll.clientWidth < scroll.scrollWidth - 1);
    if (a !== this.clipStart) this.clipStart = a;
    if (b !== this.clipEnd) this.clipEnd = b;
  }
  position() {
    if (!this.hasMenu) return;
    const nav = this.template.querySelector('.gnb'),
      trigger = this.template.querySelector(`[data-key="${this.menuKey}"]`),
      menu = this.template.querySelector('.gnb-popover');
    if (!nav || !trigger || !menu) return;
    const a = nav.getBoundingClientRect(),
      b = trigger.getBoundingClientRect();
    const offset = Math.max(
      0,
      Math.min(b.left - a.left, a.width - menu.getBoundingClientRect().width),
    );
    const top = b.bottom - a.top + 4;
    if (offset !== this.offset) this.offset = offset;
    if (top !== this.menuTop) this.menuTop = top;
  }
  customerToggle() {
    if (this.disabled) return;
    const open = this.menuKey === 'customers' && this.pinned;
    this.close();
    if (!open) {
      this.menuKey = 'customers';
      this.pinned = true;
    }
  }
  requestAdd() {
    if (this.canAdd)
      emit(this, 'session_action', {
        action: 'add',
      });
  }
  activate(event) {
    const item = [...this.sessionsView, ...this.work].find(
      (x) => x.key === event.currentTarget.dataset.key,
    );
    if (!item || item.disabled) {
      event.preventDefault();
      return;
    }
    this.close();
    if (modifiedClick(event)) return;
    const task =
      item.children.find((x) => x.id === this.recent[item.id]) ||
      item.children.find((x) => !x.disabled);
    emit(this, 'navigate', {
      id: item.id,
      sessionId: item.id,
      taskId: task?.id,
      label: item.label,
      href: item.href,
    });
  }
  hover(event) {
    if (this.pinned || this.disabled) return;
    this.cancelLeave();
    const item = this.sessionsView.find(
      (x) => x.key === event.currentTarget.dataset.key,
    );
    this.menuKey =
      item && !item.active && !item.disabled && item.hasChildren
        ? item.key
        : '';
  }
  handleChild(event) {
    const groupKey = event.currentTarget.dataset.group;
    const group =
      this.sessionsView.find((x) => x.key === groupKey) || this.menuGroup;
    const item =
      group?.children.find((x) => x.key === event.currentTarget.dataset.key) ||
      this.menuItems.find((x) => x.key === event.currentTarget.dataset.key);
    if (!item || item.disabled) return;
    const session =
      group || this.sessionsView.find((entry) => entry.id === item.id);
    const task = group
      ? item
      : session?.children.find(
          (entry) => entry.id === this.recent[session.id] && !entry.disabled,
        ) || session?.children.find((entry) => !entry.disabled);
    const sessionId = session?.id || item.id;
    if (session && task)
      this.recent = {
        ...this.recent,
        [session.id]: task.id,
      };
    this.close();
    emit(this, 'navigate', {
      id: item.id,
      sessionId,
      taskId: task?.id,
      label: item.label,
      href: item.href,
    });
  }
  cancelLeave() {
    clearTimeout(this.leaveTimer);
  }
  leave() {
    if (!this.pinned) {
      this.cancelLeave();
      this.leaveTimer = setTimeout(() => this.close(), 120);
    }
  }
  blur(event) {
    if (event.relatedTarget && !this.template.contains(event.relatedTarget))
      this.close();
  }
  close() {
    this.cancelLeave();
    this.menuKey = '';
    this.pinned = false;
  }
  scroll(event) {
    this.syncOverflow(event.currentTarget);
    if (!this.pinned) this.close();
    else this.position();
  }
  keys(event) {
    if (this.disabled) return;
    if (event.key === 'Escape' && this.hasMenu) {
      event.preventDefault();
      const key = this.menuKey;
      this.close();
      this.template.querySelector(`[data-key="${key}"]`)?.focus();
      return;
    }
    const inside = event.target.closest?.('.gnb-popover');
    if (inside) {
      const buttons = [
        ...this.template.querySelectorAll('.gnb-menu-item:not([disabled])'),
      ];
      const index = nextIndex(
        buttons,
        buttons.indexOf(event.target),
        event.key,
      );
      if (index >= 0) {
        event.preventDefault();
        buttons[index].focus();
      }
      return;
    }
    if (event.key === 'ArrowDown') {
      const item = this.sessionsView.find(
        (x) => x.key === event.target.dataset.key,
      );
      if (event.target.dataset.key === 'customers' || item?.hasChildren) {
        event.preventDefault();
        this.menuKey = event.target.dataset.key;
        this.pinned = true;
        this.focusMenu = true;
        return;
      }
    }
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    const buttons = [
      ...this.template.querySelectorAll('[data-nav-focus]:not([disabled])'),
    ];
    const index = nextIndex(buttons, buttons.indexOf(event.target), event.key);
    if (index >= 0) {
      event.preventDefault();
      buttons[index].focus();
      buttons[index].scrollIntoView({
        block: 'nearest',
        inline: 'nearest',
      });
    }
  }
}
