import { api, LightningElement } from 'lwc';
import { normalizeItems, emit, modifiedClick } from 'c/novaNavigationUtils';
export default class NovaAnchor extends LightningElement {
  @api
  items = [];
  @api
  activeId = '';
  @api
  expanded = false;
  @api
  disabled = false;
  _showTop = true;
  @api
  get showTop() {
    return this._showTop;
  }
  set showTop(value) {
    this._showTop = value === true || value === '' || value === 'true';
  }
  @api
  label = '페이지 내 이동';
  opensLeft = false;
  get expandLeft() {
    return String(this.opensLeft);
  }
  align() {
    const left = this.hostElement.getBoundingClientRect().left;
    this.opensLeft = left >= 66;
  }
  renderedCallback() {
    this.align();
  }
  get state() {
    return this.expanded ? 'hovered' : 'default';
  }
  get links() {
    return normalizeItems(this.items).map((item) => ({
      ...item,
      disabled: this.disabled || item.disabled,
      href: this.disabled || item.disabled ? undefined : item.href,
      current: item.id === this.activeId ? 'location' : null,
    }));
  }
  navigate(event) {
    const item = this.links.find(
      (x) => x.key === event.currentTarget.dataset.key,
    );
    if (!item || item.disabled) {
      event.preventDefault();
      return;
    }
    if (!modifiedClick(event))
      emit(this, 'navigate', {
        id: item.id,
        label: item.label,
        href: item.href,
        targetId: item.targetId,
      });
  }
  top() {
    if (!this.disabled) emit(this, 'top_request', {});
  }
}
