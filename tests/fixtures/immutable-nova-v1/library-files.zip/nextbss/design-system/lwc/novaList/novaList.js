import { api, LightningElement } from 'lwc';
import { normalizeItems, asText, emit } from 'c/novaNavigationUtils';
export default class NovaList extends LightningElement {
  @api
  items = [];
  @api
  variant = 'data';
  @api
  label = '데이터 목록';
  @api
  disabled = false;
  @api
  selectedIds = [];
  get entries() {
    return normalizeItems(this.items).map((item) => {
      const options = Array.isArray(item.options)
        ? item.options.map((raw, i) =>
            typeof raw === 'string'
              ? {
                  label: raw,
                  value: String(i),
                }
              : raw,
          )
        : [];
      const selected =
        options.find((x) => x.value === item.value || x.label === item.value) ||
        options[0];
      return {
        ...item,
        value: asText(item.value),
        disabled: this.disabled || item.disabled,
        options,
        hasOptions: options.length > 0,
        selectedValue: selected?.value,
        badgeTone: item.badgeTone || 'info',
        badge: asText(item.badge),
        status: asText(item.status),
        time: asText(item.time),
      };
    });
  }
  get listClass() {
    return `data list list-${this.variant}`;
  }
  get bullet() {
    return this.variant === 'bullet';
  }
  get action() {
    return this.variant === 'action';
  }
  get activity() {
    return this.variant === 'activity';
  }
  get form() {
    return this.variant === 'form';
  }
  handleAction(event) {
    const item = this.entries.find(
      (x) => x.id === event.currentTarget.dataset.id,
    );
    if (item && !item.disabled)
      emit(this, 'item_action', {
        id: item.id,
      });
  }
  change(event) {
    event.stopPropagation();
    const item = this.entries.find(
      (x) => x.id === event.currentTarget.dataset.id,
    );
    if (item && !item.disabled)
      emit(this, 'item_change', {
        id: item.id,
        value: event.detail?.value ?? event.target.value,
      });
  }
}
