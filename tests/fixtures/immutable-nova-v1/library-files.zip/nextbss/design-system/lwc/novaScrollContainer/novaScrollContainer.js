import { LightningElement, api } from 'lwc';
import { emit, finite } from 'c/novaControlUtils';
export default class NovaScrollContainer extends LightningElement {
  @api
  label = '스크롤 영역';
  @api
  orientation = 'vertical';
  @api
  maxHeight;
  @api
  viewportHeight = 240;
  get containerClass() {
    return this.orientation === 'horizontal'
      ? 'scroll-container horizontal'
      : 'scroll-container';
  }
  get containerStyle() {
    return `--nova-scroll-height:${Math.max(40, Math.min(1600, finite(this.maxHeight, finite(this.viewportHeight, 240))))}px`;
  }
  handleScroll(event) {
    emit(this, 'scroll', {
      top: event.currentTarget.scrollTop,
      left: event.currentTarget.scrollLeft,
      maxTop: Math.max(
        0,
        event.currentTarget.scrollHeight - event.currentTarget.clientHeight,
      ),
      maxLeft: Math.max(
        0,
        event.currentTarget.scrollWidth - event.currentTarget.clientWidth,
      ),
    });
    event.stopPropagation();
  }
  @api
  scrollTo(options) {
    const region = this.template.querySelector('.scroll-container');
    if (!region || !options || typeof options !== 'object') return;
    region.scrollTo({
      top: finite(options.top, region.scrollTop),
      left: finite(options.left, region.scrollLeft),
      behavior: options.behavior === 'smooth' ? 'smooth' : 'auto',
    });
  }
  @api
  focus() {
    this.template.querySelector('.scroll-container')?.focus();
  }
}
