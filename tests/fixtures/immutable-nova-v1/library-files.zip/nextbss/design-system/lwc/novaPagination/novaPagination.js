import { api, LightningElement } from 'lwc';
import { integer, emit } from 'c/novaNavigationUtils';
export default class NovaPagination extends LightningElement {
  @api
  page = 1;
  @api
  pageSize = 10;
  @api
  totalItems = 0;
  @api
  totalPages;
  @api
  disabled = false;
  @api
  variant = 'primary';
  @api
  label = '페이지 이동';
  get count() {
    return integer(this.totalItems, 0, 0);
  }
  get size() {
    return integer(this.pageSize, 10);
  }
  get pages() {
    return this.totalPages === undefined
      ? Math.max(1, Math.ceil(this.count / this.size))
      : integer(this.totalPages, 1);
  }
  get currentPage() {
    return Math.min(integer(this.page, 1), this.pages);
  }
  get atFirst() {
    return this.disabled || this.currentPage <= 1;
  }
  get atLast() {
    return this.disabled || this.currentPage >= this.pages;
  }
  get loadMore() {
    return this.variant === 'load-more';
  }
  get allLoaded() {
    return this.disabled || this.currentPage * this.size >= this.count;
  }
  get loaded() {
    return Math.min(this.currentPage * this.size, this.count);
  }
  get typed() {
    return this.variant === 'secondary';
  }
  get edges() {
    return !this.typed;
  }
  get pageItems() {
    const p = this.currentPage,
      last = this.pages;
    let values;
    if (last <= 9)
      values = Array.from(
        {
          length: last,
        },
        (_, i) => i + 1,
      );
    else {
      const set = new Set([1, last]);
      for (let n = Math.max(2, p - 2); n <= Math.min(last - 1, p + 2); n++)
        set.add(n);
      if (p < 4) for (let n = 2; n <= 6; n++) set.add(n);
      if (p > last - 3) for (let n = last - 5; n < last; n++) set.add(n);
      values = [...set].sort((a, b) => a - b);
    }
    const out = [];
    for (const n of values) {
      if (out.length && n - out.at(-1).value > 1)
        out.push({
          key: `gap-${n}`,
          ellipsis: true,
          value: n - 1,
        });
      out.push({
        key: `page-${n}`,
        value: n,
        current: n === p ? 'page' : null,
      });
    }
    return out;
  }
  request(page) {
    if (this.disabled) return;
    const next = Math.min(
      this.pages,
      Math.max(1, integer(page, this.currentPage)),
    );
    if (next !== this.currentPage)
      emit(this, 'page_change', {
        page: next,
        pageSize: this.size,
      });
  }
  first() {
    this.request(1);
  }
  previous() {
    this.request(this.currentPage - 1);
  }
  next() {
    this.request(this.currentPage + 1);
  }
  last() {
    this.request(this.pages);
  }
  select(event) {
    this.request(Number(event.currentTarget.dataset.page));
  }
  input(event) {
    const value = event.target.value;
    if (/^\d+$/.test(value)) this.request(Number(value));
    event.target.value = String(this.currentPage);
  }
  keys(event) {
    if (event.key === 'Enter') {
      event.preventDefault();
      this.input(event);
    }
    if (event.key === 'Escape') event.target.value = String(this.currentPage);
  }
  more() {
    if (!this.allLoaded)
      emit(this, 'load_more', {
        page: this.currentPage + 1,
        pageSize: this.size,
        offset: this.currentPage * this.size,
      });
  }
}
