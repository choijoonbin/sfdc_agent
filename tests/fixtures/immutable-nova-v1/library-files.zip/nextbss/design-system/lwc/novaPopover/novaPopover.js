import { LightningElement, api } from 'lwc';
import { positionFloating } from 'c/novaFloatingUtils';
import { focusFirst, restoreFocus } from 'c/novaFocusUtils';
import { normalizeActions } from 'c/novaOverlayUtils';
import { getFeedbackIcon } from 'c/novaFeedbackIcons';
export default class NovaPopover extends LightningElement {
  @api
  open = false;
  @api
  heading = '';
  @api
  content = '';
  @api
  triggerLabel = '안내';
  @api
  accessibleLabel = '추가 안내';
  @api
  actions;
  @api
  placement = 'bottom';
  @api
  disabled = false;
  @api
  standalone = false;
  positionStyle = '';
  actualPlacement = 'bottom';
  _view;
  _wasOpen = false;
  _restoreOnClose = false;
  get visible() {
    return !this.disabled && this.open;
  }
  get hidden() {
    return !this.visible;
  }
  get floatingStyle() {
    return this.standalone ? undefined : this.positionStyle;
  }
  get panelPlacement() {
    return this.standalone &&
      ['top', 'right', 'bottom', 'left'].includes(this.placement)
      ? this.placement
      : this.actualPlacement;
  }
  get actionItems() {
    return normalizeActions(this.actions, [], this.disabled);
  }
  get dialogLabel() {
    return this.heading || this.accessibleLabel;
  }
  get closePath() {
    return getFeedbackIcon('close').paths[0].d;
  }
  handleTrigger() {
    if (this.visible) this.requestClose('trigger');
    else if (!this.disabled)
      this.dispatchEvent(
        new CustomEvent('open_change', {
          detail: {
            open: true,
            reason: 'trigger',
          },
        }),
      );
  }
  requestClose(reason) {
    this._restoreOnClose = !['outside', 'blur'].includes(reason);
    this.dispatchEvent(
      new CustomEvent('request_close', {
        detail: {
          reason,
        },
      }),
    );
  }
  handleClose() {
    this.requestClose('close-button');
  }
  handleKeyDown(event) {
    if (event.key === 'Escape' && this.visible) {
      event.preventDefault();
      event.stopPropagation();
      this.requestClose('escape');
    }
  }
  handleAction(event) {
    const action = this.actionItems.find(
      (item) => item.id === event.currentTarget.dataset.id,
    );
    if (!action || action.disabled) return;
    this.dispatchEvent(
      new CustomEvent('action', {
        detail: {
          id: action.id,
          ...(action.value === undefined
            ? {}
            : {
                value: action.value,
              }),
        },
      }),
    );
    if (action.dismiss) this.requestClose('action');
  }
  handleOutside = (event) => {
    if (this.visible && !event.composedPath().includes(this.hostElement))
      this.requestClose('outside');
  };
  handleReposition = () => {
    this.updatePosition();
  };
  updatePosition() {
    const trigger = this.template.querySelector('.tip-trigger');
    const panel = this.template.querySelector('.tip-content');
    if (!this.visible || this.standalone || !trigger || !panel) return;
    const view = trigger.ownerDocument.defaultView;
    const result = positionFloating(
      trigger.getBoundingClientRect(),
      panel.getBoundingClientRect(),
      {
        width: view.innerWidth,
        height: view.innerHeight,
      },
      this.placement,
    );
    const next = `left:${result.left}px;top:${result.top}px`;
    if (next !== this.positionStyle) this.positionStyle = next;
    if (result.placement !== this.actualPlacement)
      this.actualPlacement = result.placement;
  }
  renderedCallback() {
    if (this.visible) {
      this.updatePosition();
      if (!this._view) {
        this._view = this.hostElement.ownerDocument.defaultView;
        this._view.addEventListener('pointerdown', this.handleOutside, true);
        this._view.addEventListener('resize', this.handleReposition);
        this._view.addEventListener('scroll', this.handleReposition, true);
      }
      if (!this._wasOpen && !this.standalone) {
        const panel = this.template.querySelector('.tip-content');
        focusFirst(panel, panel);
      }
    } else {
      this.stopWatching();
      if (this._wasOpen && this._restoreOnClose)
        restoreFocus(this.template.querySelector('.tip-trigger'));
      this._restoreOnClose = false;
    }
    this._wasOpen = this.visible;
  }
  stopWatching() {
    if (this._view) {
      this._view.removeEventListener('pointerdown', this.handleOutside, true);
      this._view.removeEventListener('resize', this.handleReposition);
      this._view.removeEventListener('scroll', this.handleReposition, true);
      this._view = undefined;
    }
  }
  disconnectedCallback() {
    this.stopWatching();
  }
}
