export function asText(value) {
  return typeof value === 'string' || typeof value === 'number'
    ? String(value)
    : '';
}
export function safeHref(value) {
  if (typeof value !== 'string' || /[\u0000-\u0020\\]/.test(value))
    return undefined;
  if (/^#[A-Za-z0-9][A-Za-z0-9_.:%-]*$/.test(value) || /^\/(?!\/)/.test(value))
    return value;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password
      ? url.href
      : undefined;
  } catch {
    return undefined;
  }
}
export function normalizeItems(value, scope = 'item', depth = 0) {
  if (!Array.isArray(value)) return [];
  const ids = new Set();
  return value.flatMap((raw, index) => {
    const item =
      typeof raw === 'string'
        ? {
            label: raw,
          }
        : raw;
    if (!item || !asText(item.label).trim()) return [];
    const id = asText(item.id ?? item.value) || `${scope}-${index}`;
    if (ids.has(id)) return [];
    ids.add(id);
    const children =
      depth < 4
        ? normalizeItems(item.children, `${scope}-${index}`, depth + 1)
        : [];
    return [
      {
        ...item,
        id,
        key: `${scope}-${index}`,
        label: asText(item.label),
        disabled: item.disabled === true || item.state === 'disabled',
        href: safeHref(item.href),
        children,
        hasChildren: children.length > 0,
        detail: asText(item.detail),
        content: asText(item.content),
        hasCount: typeof item.count === 'string' || Number.isFinite(item.count),
      },
    ];
  });
}
export function integer(value, fallback = 1, min = 1) {
  const n = Number(value);
  return Number.isSafeInteger(n) && n >= min ? n : fallback;
}
export function nextIndex(items, current, key) {
  if (!items.length) return -1;
  if (key === 'Home') return 0;
  if (key === 'End') return items.length - 1;
  const delta = {
    ArrowLeft: -1,
    ArrowUp: -1,
    ArrowRight: 1,
    ArrowDown: 1,
  }[key];
  return delta
    ? ((current < 0 ? 0 : current) + delta + items.length) % items.length
    : -1;
}
export function emit(component, type, detail) {
  component.dispatchEvent(
    new CustomEvent(type, {
      detail,
    }),
  );
}
export function modifiedClick(event) {
  return (
    event.ctrlKey ||
    event.metaKey ||
    event.altKey ||
    event.shiftKey ||
    event.button > 0
  );
}
let sequence = 0;
export function nextId(prefix = 'nova') {
  sequence += 1;
  return `${prefix}-${sequence}`;
}
const navigationIcons = {
  search:
    'M26.19 28.31 C26.78 28.9 27.72 28.9 28.31 28.31 C28.9 27.72 28.9 26.78 28.31 26.19 L27.25 27.25 L26.19 28.31 Z M22.87 20.75 C22.29 20.17 21.34 20.17 20.75 20.75 C20.17 21.34 20.17 22.29 20.75 22.87 L21.81 21.81 L22.87 20.75 Z M24.75 14.75 L23.25 14.75 C23.25 19.44 19.44 23.25 14.75 23.25 L14.75 24.75 L14.75 26.25 C21.1 26.25 26.25 21.1 26.25 14.75 L24.75 14.75 Z M14.75 24.75 L14.75 23.25 C10.06 23.25 6.25 19.44 6.25 14.75 L4.75 14.75 L3.25 14.75 C3.25 21.1 8.4 26.25 14.75 26.25 L14.75 24.75 Z M4.75 14.75 L6.25 14.75 C6.25 10.06 10.06 6.25 14.75 6.25 L14.75 4.75 L14.75 3.25 C8.4 3.25 3.25 8.4 3.25 14.75 L4.75 14.75 Z M14.75 4.75 L14.75 6.25 C19.44 6.25 23.25 10.06 23.25 14.75 L24.75 14.75 L26.25 14.75 C26.25 8.4 21.1 3.25 14.75 3.25 L14.75 4.75 Z M27.25 27.25 L28.31 26.19 L22.87 20.75 L21.81 21.81 L20.75 22.87 L26.19 28.31 L27.25 27.25 Z',
  layers:
    'M16 3.5 L16.67 2.16 C16.25 1.95 15.75 1.95 15.33 2.16 L16 3.5 Z M3.5 9.75 L2.83 8.41 C2.32 8.66 2 9.18 2 9.75 C2 10.32 2.32 10.84 2.83 11.09 L3.5 9.75 Z M16 16 L15.33 17.34 C15.75 17.55 16.25 17.55 16.67 17.34 L16 16 Z M28.5 9.75 L29.17 11.09 C29.68 10.84 30 10.32 30 9.75 C30 9.18 29.68 8.66 29.17 8.41 L28.5 9.75 Z M4.17 20.91 C3.43 20.54 2.53 20.84 2.16 21.58 C1.79 22.32 2.09 23.22 2.83 23.59 L3.5 22.25 L4.17 20.91 Z M16 28.5 L15.33 29.84 C15.75 30.05 16.25 30.05 16.67 29.84 L16 28.5 Z M29.17 23.59 C29.91 23.22 30.21 22.32 29.84 21.58 C29.47 20.84 28.57 20.54 27.83 20.91 L28.5 22.25 L29.17 23.59 Z M4.17 14.66 C3.43 14.29 2.53 14.59 2.16 15.33 C1.79 16.07 2.09 16.97 2.83 17.34 L3.5 16 L4.17 14.66 Z M16 22.25 L15.33 23.59 C15.75 23.8 16.25 23.8 16.67 23.59 L16 22.25 Z M29.17 17.34 C29.91 16.97 30.21 16.07 29.84 15.33 C29.47 14.59 28.57 14.29 27.83 14.66 L28.5 16 L29.17 17.34 Z M16 3.5 L15.33 2.16 L2.83 8.41 L3.5 9.75 L4.17 11.09 L16.67 4.84 L16 3.5 Z M3.5 9.75 L2.83 11.09 L15.33 17.34 L16 16 L16.67 14.66 L4.17 8.41 L3.5 9.75 Z M16 16 L16.67 17.34 L29.17 11.09 L28.5 9.75 L27.83 8.41 L15.33 14.66 L16 16 Z M28.5 9.75 L29.17 8.41 L16.67 2.16 L16 3.5 L15.33 4.84 L27.83 11.09 L28.5 9.75 Z M3.5 22.25 L2.83 23.59 L15.33 29.84 L16 28.5 L16.67 27.16 L4.17 20.91 L3.5 22.25 Z M16 28.5 L16.67 29.84 L29.17 23.59 L28.5 22.25 L27.83 20.91 L15.33 27.16 L16 28.5 Z M3.5 16 L2.83 17.34 L15.33 23.59 L16 22.25 L16.67 20.91 L4.17 14.66 L3.5 16 Z M16 22.25 L16.67 23.59 L29.17 17.34 L28.5 16 L27.83 14.66 L15.33 20.91 L16 22.25 Z',
  bookmark:
    'M24.75 27.25 L23.88 28.47 C24.34 28.8 24.94 28.84 25.44 28.58 C25.94 28.33 26.25 27.81 26.25 27.25 L24.75 27.25 Z M16 21 L16.87 19.78 C16.35 19.41 15.65 19.41 15.13 19.78 L16 21 Z M7.25 27.25 L5.75 27.25 C5.75 27.81 6.06 28.33 6.56 28.58 C7.06 28.84 7.66 28.8 8.12 28.47 L7.25 27.25 Z M9.75 4.75 L9.75 3.25 L9.75 4.75 Z M22.25 4.75 L22.25 3.25 L22.25 4.75 Z M24.75 27.25 L25.62 26.03 L16.87 19.78 L16 21 L15.13 22.22 L23.88 28.47 L24.75 27.25 Z M16 21 L15.13 19.78 L6.38 26.03 L7.25 27.25 L8.12 28.47 L16.87 22.22 L16 21 Z M7.25 27.25 L8.75 27.25 L8.75 7.25 L7.25 7.25 L5.75 7.25 L5.75 27.25 L7.25 27.25 Z M7.25 7.25 L8.75 7.25 C8.75 6.98 8.86 6.73 9.04 6.54 L7.98 5.48 L6.92 4.42 C6.17 5.17 5.75 6.19 5.75 7.25 L7.25 7.25 Z M7.98 5.48 L9.04 6.54 C9.23 6.36 9.48 6.25 9.75 6.25 L9.75 4.75 L9.75 3.25 C8.69 3.25 7.67 3.67 6.92 4.42 L7.98 5.48 Z M9.75 4.75 L9.75 6.25 L22.25 6.25 L22.25 4.75 L22.25 3.25 L9.75 3.25 L9.75 4.75 Z M22.25 4.75 L22.25 6.25 C22.52 6.25 22.77 6.36 22.96 6.54 L24.02 5.48 L25.08 4.42 C24.33 3.67 23.31 3.25 22.25 3.25 L22.25 4.75 Z M24.02 5.48 L22.96 6.54 C23.14 6.73 23.25 6.98 23.25 7.25 L24.75 7.25 L26.25 7.25 C26.25 6.19 25.83 5.17 25.08 4.42 L24.02 5.48 Z M24.75 7.25 L23.25 7.25 L23.25 27.25 L24.75 27.25 L26.25 27.25 L26.25 7.25 L24.75 7.25 Z',
  user: 'M24.5 27.25 C24.5 28.08 25.17 28.75 26 28.75 C26.83 28.75 27.5 28.08 27.5 27.25 L26 27.25 L24.5 27.25 Z M21 19.75 L21 18.25 L21 19.75 Z M11 19.75 L11 18.25 L11 19.75 Z M6 24.75 L4.5 24.75 L6 24.75 Z M4.5 27.25 C4.5 28.08 5.17 28.75 6 28.75 C6.83 28.75 7.5 28.08 7.5 27.25 L6 27.25 L4.5 27.25 Z M26 27.25 L27.5 27.25 L27.5 24.75 L26 24.75 L24.5 24.75 L24.5 27.25 L26 27.25 Z M26 24.75 L27.5 24.75 C27.5 23.03 26.82 21.37 25.6 20.15 L24.54 21.21 L23.47 22.28 C24.13 22.93 24.5 23.82 24.5 24.75 L26 24.75 Z M24.54 21.21 L25.6 20.15 C24.38 18.93 22.72 18.25 21 18.25 L21 19.75 L21 21.25 C21.93 21.25 22.82 21.62 23.47 22.28 L24.54 21.21 Z M21 19.75 L21 18.25 L11 18.25 L11 19.75 L11 21.25 L21 21.25 L21 19.75 Z M11 19.75 L11 18.25 C9.28 18.25 7.62 18.93 6.4 20.15 L7.46 21.21 L8.53 22.28 C9.18 21.62 10.07 21.25 11 21.25 L11 19.75 Z M7.46 21.21 L6.4 20.15 C5.18 21.37 4.5 23.03 4.5 24.75 L6 24.75 L7.5 24.75 C7.5 23.82 7.87 22.93 8.53 22.28 L7.46 21.21 Z M6 24.75 L4.5 24.75 L4.5 27.25 L6 27.25 L7.5 27.25 L7.5 24.75 L6 24.75 Z M21 9.75 L19.5 9.75 C19.5 11.68 17.93 13.25 16 13.25 L16 14.75 L16 16.25 C19.59 16.25 22.5 13.34 22.5 9.75 L21 9.75 Z M16 14.75 L16 13.25 C14.07 13.25 12.5 11.68 12.5 9.75 L11 9.75 L9.5 9.75 C9.5 13.34 12.41 16.25 16 16.25 L16 14.75 Z M11 9.75 L12.5 9.75 C12.5 7.82 14.07 6.25 16 6.25 L16 4.75 L16 3.25 C12.41 3.25 9.5 6.16 9.5 9.75 L11 9.75 Z M16 4.75 L16 6.25 C17.93 6.25 19.5 7.82 19.5 9.75 L21 9.75 L22.5 9.75 C22.5 6.16 19.59 3.25 16 3.25 L16 4.75 Z',
};
export function navigationIcon(name) {
  return Object.hasOwn(navigationIcons, name)
    ? navigationIcons[name]
    : undefined;
}
