export function normalizeActions(value, fallback = [], disabled = false) {
  const source = Array.isArray(value) ? value : fallback;
  const seen = new Set();
  return source
    .filter((item) => item && typeof item === 'object')
    .map((item, index) => ({
      id: String(item.id ?? `action-${index}`),
      label: String(item.label ?? ''),
      variant: String(item.variant ?? 'secondary'),
      disabled: disabled || item.disabled === true,
      dismiss: item.dismiss === true,
      value: item.value,
    }))
    .filter((item) => {
      if (seen.has(item.id)) return false;
      seen.add(item.id);
      return true;
    });
}
// Native modal is intentionally confined by the NOVA-only host/iframe contract.
// This helper never changes body styles, outside DOM, inert attributes or an app overlay manager.
export function synchronizeDialog(dialog, open, modal = true) {
  if (!dialog?.isConnected) return;
  if (open && !dialog.open) {
    if (modal) dialog.showModal();
    else dialog.show();
  } else if (!open && dialog.open) dialog.close();
}
export function isBackdropPress(event, dialog) {
  if (event.target !== dialog) return false;
  const rect = dialog.getBoundingClientRect();
  return (
    event.clientX < rect.left ||
    event.clientX > rect.right ||
    event.clientY < rect.top ||
    event.clientY > rect.bottom
  );
}
