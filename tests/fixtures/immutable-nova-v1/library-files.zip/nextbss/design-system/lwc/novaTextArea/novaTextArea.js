import { LightningElement, api } from 'lwc';
import {
  stateClass,
  isDisabled,
  isReadOnly,
  emit,
  safeFieldStyle,
  finite,
} from 'c/novaControlUtils';
export default class NovaTextArea extends LightningElement {
  @api
  label = '';
  @api
  accessibleLabel = '';
  @api
  hideLabel = false;
  @api
  size = 'large';
  @api
  state = '';
  @api
  disabled = false;
  @api
  readOnly = false;
  @api
  required = false;
  @api
  placeholder = '';
  @api
  helperText = '';
  @api
  errorMessage = '';
  @api
  maxLength;
  @api
  widthBehavior = '';
  @api
  libraryAppearance = '';
  @api
  fieldBackground = '';
  @api
  fieldBorderColor = '';
  @api
  helperIndicator = false;
  @api
  name = '';
  @api
  value = '';
  @api
  rows = 4;
  @api
  hideCounter = false;
  @api
  resize = 'vertical';
  get rootClass() {
    return stateClass(this);
  }
  get labelClass() {
    return this.hideLabel ? 'label hidden-label' : 'label';
  }
  get disabledValue() {
    return isDisabled(this);
  }
  get readonlyValue() {
    return isReadOnly(this);
  }
  get locked() {
    return this.disabledValue || this.readonlyValue;
  }
  get requiredValue() {
    return this.required || this.state === 'required';
  }
  get invalid() {
    return !!this.errorMessage || this.state === 'error';
  }
  get description() {
    return this.errorMessage || this.helperText;
  }
  get describedBy() {
    return this.description ? 'helper' : undefined;
  }
  get inputLabel() {
    return this.accessibleLabel || this.label || '입력';
  }
  get sourceStyle() {
    return safeFieldStyle(this);
  }
  handleInput(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'input', {
        value: event.target.value,
      });
  }
  handleChange(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'change', {
        value: event.target.value,
      });
  }
  @api
  focus() {
    this.template.querySelector('input,textarea')?.focus();
  }
  @api
  checkValidity() {
    const field = this.template.querySelector('input,textarea');
    field?.setCustomValidity(this.errorMessage || '');
    return field?.checkValidity() ?? true;
  }
  @api
  reportValidity() {
    const field = this.template.querySelector('input,textarea');
    field?.setCustomValidity(this.errorMessage || '');
    return field?.reportValidity() ?? true;
  }
  get isVerifiedTableArea() {
    return this.libraryAppearance === 'verified-table-area';
  }
  get limit() {
    return finite(this.maxLength, 500);
  }
  get count() {
    return `${String(this.value ?? '').length} / ${this.limit}`;
  }
  get showCounter() {
    return !this.hideCounter;
  }
  get showSupport() {
    return this.description || this.showCounter;
  }
  get areaStyle() {
    return `resize:${['none', 'vertical', 'both'].includes(this.resize) ? this.resize : 'vertical'}`;
  }
  renderedCallback() {
    const area = this.template.querySelector('textarea');
    if (area && area.value !== String(this.value ?? ''))
      area.value = String(this.value ?? '');
  }
}
