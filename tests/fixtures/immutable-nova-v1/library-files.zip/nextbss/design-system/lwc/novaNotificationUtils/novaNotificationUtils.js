// Per-instance timer. Pausing never starts a second timer and disposal clears all work.
export function createNotificationTimer(onTimeout) {
  let timeout;
  let remaining = 0;
  let started = 0;
  let disposed = false;
  function clear() {
    if (timeout !== undefined) clearTimeout(timeout);
    timeout = undefined;
    remaining = 0;
  }
  function schedule() {
    if (disposed || remaining <= 0 || timeout !== undefined) return;
    started = Date.now();
    timeout = setTimeout(() => {
      timeout = undefined;
      remaining = 0;
      if (!disposed) onTimeout();
    }, remaining);
  }
  return {
    start(duration) {
      clear();
      if (
        !disposed &&
        Number.isFinite(Number(duration)) &&
        Number(duration) > 0
      ) {
        remaining = Math.min(Number(duration), 2147483647);
        schedule();
      }
    },
    pause() {
      if (timeout !== undefined) {
        clearTimeout(timeout);
        timeout = undefined;
        remaining = Math.max(1, remaining - (Date.now() - started));
      }
    },
    resume() {
      schedule();
    },
    clear,
    dispose() {
      clear();
      disposed = true;
    },
  };
}
