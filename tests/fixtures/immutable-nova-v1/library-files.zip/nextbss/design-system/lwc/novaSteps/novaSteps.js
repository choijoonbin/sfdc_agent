import { api, LightningElement } from 'lwc';
import { normalizeItems, emit } from 'c/novaNavigationUtils';
export default class NovaSteps extends LightningElement {
  @api
  items = [];
  @api
  currentId = '';
  @api
  interactive = false;
  @api
  disabled = false;
  @api
  variant = 'primary';
  @api
  label = '업무 진행 단계';
  get steps() {
    return normalizeItems(this.items).map((item, index) => {
      const state =
        item.id === this.currentId
          ? 'active'
          : ['active', 'completed', 'disabled'].includes(item.state)
            ? item.state
            : 'default';
      return {
        ...item,
        state,
        number: item.number ?? index + 1,
        disabled: this.disabled || item.disabled,
        completed: state === 'completed',
        showCheck: state === 'completed',
        current: state === 'active' ? 'step' : null,
      };
    });
  }
  select(event) {
    const item = this.steps.find(
      (x) => x.key === event.currentTarget.dataset.key,
    );
    if (this.interactive && item && !item.disabled)
      emit(this, 'step_select', {
        id: item.id,
        label: item.label,
      });
  }
}
