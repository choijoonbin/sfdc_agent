import { LightningElement, api } from 'lwc';
const SHAPES = new Set(['text', 'circle', 'rectangle', 'capsule', 'graph']);
function dimension(value, width = false) {
  if (
    typeof value === 'number' &&
    Number.isFinite(value) &&
    value > 0 &&
    value <= 4096
  )
    return `${value}px`;
  if (
    width &&
    typeof value === 'string' &&
    /^\d{1,3}(?:\.\d{1,2})?%$/.test(value) &&
    Number.parseFloat(value) > 0 &&
    Number.parseFloat(value) <= 100
  )
    return value;
  return undefined;
}
export default class NovaSkeleton extends LightningElement {
  @api
  items;
  @api
  shape = 'text';
  @api
  count = 1;
  @api
  motion = 'auto';
  @api
  accessibleLabel;
  get staticMotion() {
    return (
      this.motion === false ||
      this.motion === 'none' ||
      this.motion === 'static'
    );
  }
  get statusRole() {
    return this.accessibleLabel ? 'status' : undefined;
  }
  get decorative() {
    return this.accessibleLabel ? undefined : 'true';
  }
  get busy() {
    return this.accessibleLabel ? 'true' : undefined;
  }
  get shapes() {
    const source =
      Array.isArray(this.items) && this.items.length
        ? this.items.slice(0, 100)
        : Array.from(
            {
              length: Math.min(
                100,
                Math.max(1, Math.floor(Number(this.count) || 1)),
              ),
            },
            (_, index) => ({
              id: index,
              shape: this.shape,
            }),
          );
    return source.map((item, index) => {
      const width = dimension(item.width, true);
      const height = dimension(item.height);
      return {
        id: `${String(item.id ?? index)}-${index}`,
        shape: SHAPES.has(item.shape) ? item.shape : 'text',
        style: [
          width && `inline-size:${width}`,
          height && `block-size:${height}`,
        ]
          .filter(Boolean)
          .join(';'),
      };
    });
  }
}
