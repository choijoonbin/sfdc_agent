// Only inspect the explicitly supplied NOVA root and its assigned slot content.
const SELECTOR =
  'button:not([disabled]),a[href],input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]';
function usable(element) {
  const style = element?.ownerDocument?.defaultView?.getComputedStyle(element);
  return (
    element &&
    style?.visibility !== 'hidden' &&
    style?.display !== 'none' &&
    element.tabIndex >= 0 &&
    !element.hidden &&
    !element.inert &&
    element.getAttribute?.('aria-hidden') !== 'true' &&
    element.getAttribute?.('aria-disabled') !== 'true' &&
    (!element.getClientRects || element.getClientRects().length > 0)
  );
}
export function getFocusableElements(root) {
  if (!root?.querySelectorAll) return [];
  const candidates = [];
  function collect(container, includeSelf = false) {
    if (includeSelf && container.matches?.(SELECTOR))
      candidates.push(container);
    for (const element of container.querySelectorAll?.(`${SELECTOR},slot`) ??
      []) {
      if (element.tagName?.toLowerCase() === 'slot') {
        for (const assigned of element.assignedElements?.({
          flatten: true,
        }) ?? [])
          collect(assigned, true);
      } else candidates.push(element);
    }
  }
  collect(root);
  return [...new Set(candidates)].filter(usable);
}
export function focusFirst(root, fallback) {
  const target = getFocusableElements(root)[0] ?? fallback;
  if (!target?.focus) return false;
  target.focus({
    preventScroll: true,
  });
  return true;
}
export function restoreFocus(element) {
  if (!element?.isConnected || !element.focus) return false;
  element.focus({
    preventScroll: true,
  });
  return true;
}
export function trapFocus(event, root) {
  if (event.key !== 'Tab') return false;
  const elements = getFocusableElements(root);
  if (!elements.length) {
    event.preventDefault();
    root?.focus?.({
      preventScroll: true,
    });
    return true;
  }
  const path = event.composedPath?.() ?? [event.target];
  const first = elements[0];
  const last = elements[elements.length - 1];
  if (event.shiftKey && path.includes(first)) {
    event.preventDefault();
    last.focus();
    return true;
  }
  if (!event.shiftKey && path.includes(last)) {
    event.preventDefault();
    first.focus();
    return true;
  }
  return false;
}
