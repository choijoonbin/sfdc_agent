import { LightningElement, api } from 'lwc';
import {
  optionsOf,
  asList,
  toggleValue,
  toggleAll,
  groupState,
} from 'c/novaSelectionUtils';
import { stateClass, isDisabled, isReadOnly, emit } from 'c/novaControlUtils';
export default class NovaCheckboxGroup extends LightningElement {
  @api
  label = '';
  @api
  options = [];
  @api
  values = [];
  @api
  disabled = false;
  @api
  readOnly = false;
  @api
  required = false;
  @api
  size = 'small';
  @api
  state = '';
  @api
  orientation = 'horizontal';
  @api
  selectAll = false;
  @api
  selectAllLabel = '전체 선택';
  @api
  helperText = '';
  @api
  errorMessage = '';
  get rootClass() {
    return stateClass(this);
  }
  get groupClass() {
    return this.orientation === 'vertical' ? 'choices vertical' : 'choices';
  }
  get requiredValue() {
    return this.required || this.state === 'required';
  }
  get locked() {
    return isDisabled(this) || isReadOnly(this);
  }
  get selection() {
    return groupState(this.values, this.options);
  }
  get allChecked() {
    return this.selection.all;
  }
  get allDisabled() {
    return this.locked || this.selection.disabled;
  }
  get rows() {
    const selected = new Set(asList(this.values));
    return optionsOf(this.options).map((option) => ({
      ...option,
      selected: selected.has(option.value),
      disabled: this.locked || option.disabled,
    }));
  }
  get description() {
    return this.errorMessage || this.helperText;
  }
  get describedBy() {
    return this.description ? 'helper' : undefined;
  }
  get invalid() {
    return !!this.errorMessage || this.state === 'error';
  }
  renderedCallback() {
    const all = this.template.querySelector('[data-select-all]');
    if (all) all.indeterminate = this.selection.mixed;
  }
  handleChange(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'change', {
        values: toggleValue(
          this.values,
          event.target.value,
          event.target.checked,
        ),
      });
  }
  handleAll(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'change', {
        values: toggleAll(this.values, this.options, event.target.checked),
      });
  }
  @api
  focus() {
    this.template.querySelector('input:not(:disabled)')?.focus();
  }
  @api
  checkValidity() {
    return !this.requiredValue || this.locked || asList(this.values).length > 0;
  }
  @api
  reportValidity() {
    return this.checkValidity();
  }
}
