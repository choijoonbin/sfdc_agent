import { asText } from 'c/novaNavigationUtils';
const states = new Set([
  'selected',
  'disabled',
  'highlight',
  'expanded',
  'error',
  'hovered',
  'info',
]);
export function columnsOf(value) {
  if (!Array.isArray(value)) return [];
  const seen = new Set();
  return value.flatMap((raw, index) => {
    const item =
      typeof raw === 'string'
        ? {
            label: raw,
          }
        : raw;
    if (!item) return [];
    const id =
      asText(item.id ?? item.fieldName ?? item.key) || `column-${index}`;
    if (seen.has(id)) return [];
    seen.add(id);
    const align = ['left', 'center', 'right'].includes(item.align)
      ? item.align
      : item.type === 'currency'
        ? 'right'
        : ['number', 'status'].includes(item.type)
          ? 'center'
          : 'left';
    return [
      {
        ...item,
        id,
        key: `column-${index}`,
        label: asText(item.label),
        className: `align-${align}`,
      },
    ];
  });
}
export function rowsOf(value, columns, rowKey = 'id') {
  if (!Array.isArray(value)) return [];
  const seen = new Set();
  return value.flatMap((row, index) => {
    if (!row || typeof row !== 'object') return [];
    const id = asText(row[rowKey] ?? row.id) || `row-${index}`;
    if (seen.has(id)) return [];
    seen.add(id);
    return [
      {
        ...row,
        id,
        key: `row-${index}`,
        detailKey: `row-${index}-details`,
        disabled: row.disabled === true || row.state === 'disabled',
        state: states.has(row.state) ? row.state : '',
        cells: columns.map((column, i) => {
          const raw = Array.isArray(row.cells)
            ? row.cells[i]
            : row[column.fieldName ?? column.id];
          const item =
            raw && typeof raw === 'object'
              ? raw
              : {
                  value: raw,
                };
          const lines = Array.isArray(item.lines)
            ? item.lines.map((line, j) => ({
                id: `line-${j}`,
                text: asText(line),
              }))
            : [];
          return {
            ...item,
            id: column.id,
            key: column.key,
            label: column.label,
            value: asText(item.value),
            lines,
            hasLines: lines.length > 0,
            status: item.type === 'status',
            className: `${column.className} ${states.has(item.state) ? `cell-${item.state}` : ''}`,
            slotClass: [20, 24, 28, 30, 32].includes(item.slotHeight)
              ? `cell-slot slot-${item.slotHeight}`
              : '',
            button: item.type === 'button',
            input: item.type === 'input',
            inputType: ['text', 'number', 'email', 'tel'].includes(
              item.inputType,
            )
              ? item.inputType
              : 'text',
          };
        }),
      },
    ];
  });
}
export function sortRows(rows, columns, sort) {
  const column = columns.find((x) => x.id === sort?.columnId);
  if (!column) return [...rows];
  const index = columns.indexOf(column),
    direction = sort.direction === 'descending' ? -1 : 1;
  return rows
    .map((row, index) => ({
      row,
      index,
    }))
    .sort((a, b) => {
      const left = a.row.cells[index]?.value ?? '',
        right = b.row.cells[index]?.value ?? '';
      let order;
      if (['number', 'currency'].includes(column.type)) {
        const l = left.trim() === '' ? NaN : Number(left.replaceAll(',', '')),
          r = right.trim() === '' ? NaN : Number(right.replaceAll(',', ''));
        if (!Number.isFinite(l))
          return Number.isFinite(r) ? 1 : a.index - b.index;
        if (!Number.isFinite(r)) return -1;
        order = l - r;
      } else
        order = left.localeCompare(right, undefined, {
          numeric: true,
        });
      return order * direction || a.index - b.index;
    })
    .map((x) => x.row);
}
export function toggleRowSelection(current, id, checked, single = false) {
  const values = new Set(single ? [] : Array.isArray(current) ? current : []);
  if (checked) values.add(id);
  else values.delete(id);
  return [...values];
}
