import { api, LightningElement } from 'lwc';
import { normalizeItems, nextIndex, nextId, emit } from 'c/novaNavigationUtils';
export default class NovaTabs extends LightningElement {
  @api
  items = [];
  _value = '';
  @api
  get value() {
    return this._value;
  }
  set value(value) {
    if (value !== this._value) {
      this._value = value;
      this.focused = '';
    }
  }
  @api
  variant = 'primary';
  @api
  activationMode = 'automatic';
  @api
  disabled = false;
  @api
  label = '탭';
  panelItems = [];
  focused = '';
  prefix = nextId('nova-tabs');
  get source() {
    return normalizeItems(this.items?.length ? this.items : this.panelItems);
  }
  get selected() {
    return (
      this.source.find((x) => x.id === this.value && !x.disabled)?.id ||
      this.source.find((x) => !x.disabled)?.id ||
      ''
    );
  }
  get tabItems() {
    return this.source.map((item) => ({
      ...item,
      tabId: `${this.prefix}-${item.key}`,
      selected: String(item.id === this.selected),
      tabIndex: item.id === (this.focused || this.selected) ? 0 : -1,
      disabled: this.disabled || item.disabled,
    }));
  }
  get content() {
    return this.source.find((x) => x.id === this.selected)?.content || '';
  }
  get fallback() {
    return !this.panelItems.length && Boolean(this.selected);
  }
  handlePanelChange(event) {
    event.stopPropagation();
    const slot = this.template.querySelector('slot');
    if (slot)
      this.handleSlot({
        target: slot,
      });
  }
  handleSlot(event) {
    const panels = event.target
      .assignedElements({
        flatten: true,
      })
      .filter((x) => typeof x.setTabState === 'function');
    const next = panels.map((x) => ({
      id: x.value,
      label: x.label,
      disabled: x.disabled,
      count: x.count,
    }));
    if (JSON.stringify(next) !== JSON.stringify(this.panelItems))
      this.panelItems = next;
    this.syncPanels();
  }
  get panels() {
    return (
      this.template
        .querySelector('slot')
        ?.assignedElements({
          flatten: true,
        })
        .filter((x) => typeof x.setTabState === 'function') || []
    );
  }
  renderedCallback() {
    this.syncPanels();
  }
  syncPanels() {
    const buttons = [...this.template.querySelectorAll('[role="tab"]')];
    for (const panel of this.panels) {
      const item = this.tabItems.find((x) => x.id === panel.value);
      const button = buttons.find((x) => x.dataset.key === item?.key);
      panel.setTabState(panel.value === this.selected, button);
      if (button) {
        if ('ariaControlsElements' in button)
          button.ariaControlsElements = [panel];
        else if (panel.id) button.setAttribute('aria-controls', panel.id);
      }
    }
    const fallback = this.template.querySelector('[data-fallback]');
    if (fallback) {
      const trigger = buttons.find(
        (x) => x.getAttribute('aria-selected') === 'true',
      );
      if (trigger) {
        fallback.setAttribute('aria-labelledby', trigger.id);
        trigger.setAttribute('aria-controls', fallback.id);
      }
    }
  }
  choose(event) {
    const item = this.tabItems.find(
      (x) => x.key === event.currentTarget.dataset.key,
    );
    if (item && !item.disabled) {
      this.focused = item.id;
      emit(this, 'change', {
        value: item.id,
      });
    }
  }
  keys(event) {
    if (this.disabled) return;
    const enabled = this.tabItems.filter((x) => !x.disabled);
    const at = enabled.findIndex(
      (x) => x.key === event.currentTarget.dataset.key,
    );
    const index = nextIndex(enabled, at, event.key);
    if (index >= 0) {
      event.preventDefault();
      const item = enabled[index];
      this.focused = item.id;
      this.template.querySelector(`[data-key="${item.key}"]`)?.focus();
      if (this.activationMode !== 'manual')
        emit(this, 'change', {
          value: item.id,
        });
    } else if (
      this.activationMode === 'manual' &&
      ['Enter', ' '].includes(event.key)
    ) {
      event.preventDefault();
      this.choose(event);
    }
  }
}
