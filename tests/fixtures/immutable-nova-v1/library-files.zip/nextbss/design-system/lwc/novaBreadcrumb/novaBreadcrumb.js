import { api, LightningElement } from 'lwc';
import { normalizeItems, emit, modifiedClick } from 'c/novaNavigationUtils';
export default class NovaBreadcrumb extends LightningElement {
  @api
  items = [];
  @api
  label = '화면 경로';
  @api
  disabled = false;
  get crumbs() {
    const items = normalizeItems(this.items);
    return items.map((item, index) => ({
      ...item,
      separated: index > 0,
      current: index === items.length - 1 ? 'page' : null,
      disabled: this.disabled || item.disabled,
      href: this.disabled || item.disabled ? undefined : item.href,
    }));
  }
  handleNavigate(event) {
    const item = this.crumbs.find(
      (x) => x.key === event.currentTarget.dataset.key,
    );
    if (!item || item.disabled) {
      event.preventDefault();
      return;
    }
    if (!modifiedClick(event))
      emit(this, 'navigate', {
        id: item.id,
        label: item.label,
        href: item.href,
      });
  }
}
