import { LightningElement, api } from 'lwc';
import { buttonIcons } from 'c/novaControlIcons';
import { stateClass, isDisabled } from 'c/novaControlUtils';
const hierarchies = new Set([
  'cta',
  'primary',
  'secondary',
  'count',
  'text',
  'action',
  'shortcut',
  'functional',
]);
const appearances = new Set([
  'filled',
  't-blue-ghost',
  'grey-ghost',
  'red-ghost',
  'red-outline',
  'outline',
  'plain',
  'neutral',
  'back',
  'ghost',
  'circle',
  'square',
  'square-fill',
  'square-bl',
  'icon-link',
]);
export default class NovaButton extends LightningElement {
  @api
  label = '';
  @api
  accessibleLabel = '';
  @api
  variant = 'filled';
  @api
  hierarchy = 'primary';
  @api
  size = 'large';
  @api
  state = '';
  @api
  disabled = false;
  @api
  loading = false;
  @api
  count = '';
  @api
  icon = '';
  @api
  iconPosition = 'leading';
  @api
  iconOnly = false;
  @api
  nodeContext = false;
  @api
  widthBehavior = '';
  @api
  libraryAppearance = '';
  get rootClass() {
    return stateClass(this);
  }
  get locked() {
    return isDisabled(this) || this.loading;
  }
  get buttonClass() {
    const hierarchy = hierarchies.has(this.variant)
      ? this.variant
      : this.hierarchy;
    const appearance = appearances.has(this.variant)
      ? this.variant
      : {
          secondary: 'outline',
          functional: 'ghost',
          count: 'filled',
        }[hierarchy] || 'filled';
    return [
      'button',
      hierarchy,
      appearance,
      this.iconOnly ? 'icon-only' : '',
      this.buttonIcon ? 'with-icon' : '',
      this.iconPosition === 'trailing' ? 'trailing' : '',
      this.icon === 'node-arrow' ? 'node-arrow' : '',
      ['hovered', 'pressed'].includes(this.state) ? this.state : '',
    ]
      .filter(Boolean)
      .join(' ');
  }
  get buttonIcon() {
    if (
      this.icon === 'node-arrow' &&
      (!this.nodeContext || this.iconPosition !== 'trailing')
    )
      return undefined;
    return buttonIcons[
      this.icon === 'back' && this.locked ? 'back-disabled' : this.icon
    ];
  }
  get showLabel() {
    return !this.iconOnly || !this.buttonIcon;
  }
  get buttonLabel() {
    return this.accessibleLabel || (!this.showLabel ? this.label : undefined);
  }
  get hasCount() {
    return this.count !== '' && this.count != null;
  }
  get busy() {
    return this.loading ? 'true' : undefined;
  }
  handleClick(event) {
    if (this.locked) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }
  @api
  focus() {
    this.template.querySelector('button')?.focus();
  }
}
