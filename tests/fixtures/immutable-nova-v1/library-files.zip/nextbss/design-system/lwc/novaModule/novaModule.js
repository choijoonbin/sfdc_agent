import { api, LightningElement } from 'lwc';
export default class NovaModule extends LightningElement {
  @api
  heading = '';
  @api
  subtitle = '';
  @api
  surface = 'default';
  @api
  content = '';
}
