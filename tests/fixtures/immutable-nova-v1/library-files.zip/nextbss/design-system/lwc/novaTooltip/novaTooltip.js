import { LightningElement, api } from 'lwc';
import { positionFloating } from 'c/novaFloatingUtils';
export default class NovaTooltip extends LightningElement {
  @api
  content = '';
  @api
  triggerLabel = '안내';
  @api
  placement = 'bottom';
  @api
  tone = 'default';
  @api
  disabled = false;
  @api
  standalone = false;
  _open = false;
  _controlled = false;
  _hovered = false;
  _focused = false;
  _hideTimer;
  _view;
  positionStyle = '';
  actualPlacement = 'bottom';
  @api
  get open() {
    return this._open;
  }
  set open(value) {
    this._controlled = value !== undefined && value !== null;
    this._open = value === true || value === '' || value === 'true';
  }
  get visible() {
    return !this.disabled && (this.standalone || this._open);
  }
  get hidden() {
    return !this.visible;
  }
  get floatingStyle() {
    return this.standalone ? undefined : this.positionStyle;
  }
  get panelPlacement() {
    return this.standalone &&
      ['top', 'right', 'bottom', 'left'].includes(this.placement)
      ? this.placement
      : this.actualPlacement;
  }
  get descriptionReference() {
    return this.content ? 'tip-content' : undefined;
  }
  requestOpen(open, reason) {
    if (open && this.disabled) return;
    if (this._controlled) {
      if (open !== this._open)
        this.dispatchEvent(
          new CustomEvent('open_change', {
            detail: {
              open,
              reason,
            },
          }),
        );
    } else this._open = open;
  }
  clearHideTimer() {
    if (this._hideTimer !== undefined) clearTimeout(this._hideTimer);
    this._hideTimer = undefined;
  }
  handleMouseEnter() {
    this.clearHideTimer();
    this._hovered = true;
    this.requestOpen(true, 'pointer');
  }
  handleMouseLeave() {
    this._hovered = false;
    this.clearHideTimer();
    this._hideTimer = setTimeout(() => {
      if (!this._focused && !this._hovered) this.requestOpen(false, 'pointer');
    }, 120);
  }
  handleFocus() {
    this.clearHideTimer();
    this._focused = true;
    this.requestOpen(true, 'focus');
  }
  handleBlur() {
    this._focused = false;
    if (!this._hovered) this.requestOpen(false, 'blur');
  }
  handleKeyDown(event) {
    if (event.key === 'Escape' && this.visible && !this.standalone) {
      event.stopPropagation();
      this.clearHideTimer();
      this._hovered = false;
      this._focused = false;
      this.requestOpen(false, 'escape');
    }
  }
  handleReposition = () => {
    this.updatePosition();
  };
  updatePosition() {
    const trigger = this.template.querySelector('.tip-trigger');
    const panel = this.template.querySelector('.tip-content');
    if (!this.visible || this.standalone || !trigger || !panel) return;
    const view = trigger.ownerDocument.defaultView;
    const position = positionFloating(
      trigger.getBoundingClientRect(),
      panel.getBoundingClientRect(),
      {
        width: view.innerWidth,
        height: view.innerHeight,
      },
      this.placement,
    );
    const next = `left:${position.left}px;top:${position.top}px`;
    if (this.positionStyle !== next) this.positionStyle = next;
    if (this.actualPlacement !== position.placement)
      this.actualPlacement = position.placement;
  }
  renderedCallback() {
    if (this.visible && !this.standalone) {
      this.updatePosition();
      if (!this._view) {
        this._view = this.hostElement.ownerDocument.defaultView;
        this._view.addEventListener('resize', this.handleReposition);
        this._view.addEventListener('scroll', this.handleReposition, true);
      }
    } else this.stopWatching();
  }
  stopWatching() {
    if (this._view) {
      this._view.removeEventListener('resize', this.handleReposition);
      this._view.removeEventListener('scroll', this.handleReposition, true);
      this._view = undefined;
    }
  }
  disconnectedCallback() {
    this.clearHideTimer();
    this.stopWatching();
  }
}
