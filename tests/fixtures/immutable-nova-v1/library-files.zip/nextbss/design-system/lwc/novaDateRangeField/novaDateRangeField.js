import { LightningElement, api } from 'lwc';
import {
  stateClass,
  isDisabled,
  isReadOnly,
  emit,
  safeFieldStyle,
} from 'c/novaControlUtils';
import { formatDate, datePart, dateAllowed } from 'c/novaDateUtils';
import { fieldIcons } from 'c/novaControlIcons';
export default class NovaDateRangeField extends LightningElement {
  @api
  label = '';
  @api
  accessibleLabel = '';
  @api
  hideLabel = false;
  @api
  size = 'large';
  @api
  state = '';
  @api
  disabled = false;
  @api
  readOnly = false;
  @api
  required = false;
  @api
  placeholder = '';
  @api
  helperText = '';
  @api
  errorMessage = '';
  @api
  widthBehavior = '';
  @api
  libraryAppearance = '';
  @api
  fieldBackground = '';
  @api
  fieldBorderColor = '';
  @api
  startValue = '';
  @api
  endValue = '';
  @api
  get value() {
    return this.startValue;
  }
  set value(v) {
    this.startValue = v ?? '';
  }
  @api
  min = '';
  @api
  max = '';
  @api
  withTime = false;
  @api
  variant = '';
  open = false;
  focusPicker = false;
  focusTrigger = false;
  localError = '';
  get rootClass() {
    return stateClass(this);
  }
  get labelClass() {
    return this.hideLabel ? 'label hidden-label' : 'label';
  }
  get disabledValue() {
    return isDisabled(this);
  }
  get readonlyValue() {
    return isReadOnly(this);
  }
  get locked() {
    return this.disabledValue || this.readonlyValue;
  }
  get requiredValue() {
    return this.required || this.state === 'required';
  }
  get describedBy() {
    return this.description ? 'helper' : undefined;
  }
  get inputLabel() {
    return this.accessibleLabel || this.label || '입력';
  }
  get sourceStyle() {
    return safeFieldStyle(this);
  }
  get verifiedTableRange() {
    return this.libraryAppearance === 'verified-table-date-range';
  }
  get range() {
    return true;
  }
  get timeEnabled() {
    return (
      this.withTime || ['date-time', 'date-time-range'].includes(this.variant)
    );
  }
  get icon() {
    return fieldIcons.calendar;
  }
  get dateClass() {
    return `date-wrap ${this.range ? (this.timeEnabled ? 'date-time-range' : 'date-range') : this.timeEnabled ? 'date-time' : 'date-only'}`;
  }
  get display() {
    return formatDate(this.value, this.timeEnabled, this.placeholder);
  }
  get endDisplay() {
    return formatDate(this.endValue, this.timeEnabled, this.placeholder);
  }
  get dateLabel() {
    return `${this.inputLabel} ${this.display}${this.range ? ' – ' + this.endDisplay : ''}`;
  }
  get description() {
    return this.localError || this.errorMessage || this.helperText;
  }
  get invalid() {
    return !!(this.localError || this.errorMessage) || this.state === 'error';
  }
  toggle() {
    if (this.locked) return;
    if (this.open) this.close();
    else {
      this.open = true;
      this.focusPicker = true;
    }
  }
  close() {
    this.open = false;
    this.focusTrigger = true;
  }
  pickerClose(event) {
    event.stopPropagation();
    this.close();
  }
  pickerChange(event) {
    event.stopPropagation();
    if (this.locked) return;
    this.localError = '';
    const detail = this.range
      ? {
          startValue: event.detail.value,
          endValue: event.detail.endValue,
          value: event.detail.value,
        }
      : {
          value: event.detail.value,
        };
    emit(this, 'change', detail);
  }
  focusOut(event) {
    if (this.open && !event.currentTarget.contains(event.relatedTarget))
      this.open = false;
  }
  renderedCallback() {
    if (this.focusPicker) {
      this.template.querySelector('c-nova-date-picker')?.focus();
      this.focusPicker = false;
    }
    if (this.focusTrigger) {
      this.template.querySelector('[data-toggle]')?.focus();
      this.focusTrigger = false;
    }
  }
  @api
  focus() {
    this.template.querySelector('[data-toggle]')?.focus();
  }
  @api
  checkValidity() {
    if (this.locked) return true;
    if (!this.value && !this.requiredValue) return true;
    if (!dateAllowed(this.value, this.min, this.max)) return false;
    return (
      !this.range ||
      (dateAllowed(this.endValue, this.min, this.max) &&
        this.value <= this.endValue)
    );
  }
  @api
  reportValidity() {
    const valid = this.checkValidity();
    this.localError = valid ? '' : '올바른 날짜 범위를 선택해 주세요.';
    return valid;
  }
}
