import { api, LightningElement } from 'lwc';
import {
  normalizeItems,
  safeHref,
  navigationIcon,
  emit,
  modifiedClick,
} from 'c/novaNavigationUtils';
export default class NovaLnb extends LightningElement {
  @api
  items = [];
  @api
  utilityItems = [];
  @api
  selectedId = '';
  @api
  rail = false;
  @api
  disabled = false;
  @api
  label = '섹션 메뉴';
  @api
  logoLabel = '';
  @api
  logoHref = '';
  @api
  homeId = '';
  get railState() {
    return String(this.rail);
  }
  prepare(items, scope) {
    return normalizeItems(items, scope).map((item) => ({
      ...item,
      disabled: this.disabled || item.disabled,
      href: this.disabled || item.disabled ? undefined : item.href,
      current: item.id === this.selectedId ? 'page' : null,
      iconPath: navigationIcon(item.icon),
    }));
  }
  get links() {
    return this.prepare(this.items, 'main');
  }
  get utilities() {
    return this.prepare(this.utilityItems, 'utility');
  }
  get homeHref() {
    return safeHref(this.logoHref);
  }
  get homeDisabled() {
    return this.disabled;
  }
  navigate(event) {
    const item = [...this.links, ...this.utilities].find(
      (x) => x.key === event.currentTarget.dataset.key,
    );
    if (!item || item.disabled) {
      event.preventDefault();
      return;
    }
    if (!modifiedClick(event))
      emit(this, 'navigate', {
        id: item.id,
        label: item.label,
        href: item.href,
      });
  }
  home(event) {
    if (this.disabled) {
      event.preventDefault();
      return;
    }
    if (!modifiedClick(event))
      emit(this, 'navigate', {
        id: this.homeId,
        href: this.homeHref,
        source: 'logo',
      });
  }
}
