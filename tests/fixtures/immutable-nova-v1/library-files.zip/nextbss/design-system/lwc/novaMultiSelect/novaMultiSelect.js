import { LightningElement, api } from 'lwc';
import {
  optionsOf,
  asList,
  toggleValue,
  toggleAll,
  groupState,
} from 'c/novaSelectionUtils';
import {
  stateClass,
  isDisabled,
  isReadOnly,
  emit,
  safeFieldStyle,
} from 'c/novaControlUtils';
import { selectChevronPath, chipDeletePath } from 'c/novaControlIcons';
export default class NovaMultiSelect extends LightningElement {
  @api
  label = '';
  @api
  accessibleLabel = '';
  @api
  hideLabel = false;
  @api
  size = 'large';
  @api
  state = '';
  @api
  disabled = false;
  @api
  readOnly = false;
  @api
  required = false;
  @api
  placeholder = '';
  @api
  helperText = '';
  @api
  errorMessage = '';
  @api
  widthBehavior = '';
  @api
  libraryAppearance = '';
  @api
  fieldBackground = '';
  @api
  fieldBorderColor = '';
  @api
  options = [];
  @api
  values = [];
  @api
  selectAll = false;
  @api
  initialOpen = false;
  opened;
  focusTrigger = false;
  get labelClass() {
    return this.hideLabel ? 'label hidden-label' : 'label';
  }
  get disabledValue() {
    return isDisabled(this);
  }
  get readonlyValue() {
    return isReadOnly(this);
  }
  get locked() {
    return this.disabledValue || this.readonlyValue;
  }
  get requiredValue() {
    return this.required || this.state === 'required';
  }
  get invalid() {
    return !!this.errorMessage || this.state === 'error';
  }
  get description() {
    return this.errorMessage || this.helperText;
  }
  get describedBy() {
    return this.description ? 'helper' : undefined;
  }
  get inputLabel() {
    return this.accessibleLabel || this.label || '입력';
  }
  get sourceStyle() {
    return safeFieldStyle(this);
  }
  get rootClass() {
    return stateClass(this, 'multi-select');
  }
  get rows() {
    const selected = new Set(asList(this.values));
    return optionsOf(this.options).map((option) => ({
      ...option,
      selected: selected.has(option.value),
      disabled: this.locked || option.disabled,
      removeLabel: `${option.label} 선택 해제`,
    }));
  }
  get chips() {
    return this.rows.filter((row) => row.selected);
  }
  get selectedCount() {
    return this.chips.length;
  }
  get hasSelection() {
    return this.selectedCount > 0;
  }
  get expanded() {
    return !this.locked && (this.opened ?? this.initialOpen);
  }
  get controls() {
    return this.expanded ? 'options' : undefined;
  }
  get allState() {
    return groupState(this.values, this.options);
  }
  get allChecked() {
    return this.allState.all;
  }
  get allDisabled() {
    return this.locked || this.allState.disabled;
  }
  get chevron() {
    return selectChevronPath;
  }
  get deleteIcon() {
    return chipDeletePath;
  }
  get selectionLabel() {
    return (
      this.label || this.accessibleLabel || this.placeholder || '다중 선택'
    );
  }
  get multiName() {
    return `${this.selectionLabel} ${this.chips.map((chip) => chip.label).join(', ')}`;
  }
  toggle() {
    if (!this.locked) this.opened = !this.expanded;
  }
  close() {
    this.opened = false;
  }
  keydown(event) {
    if (event.key === 'Escape' && this.expanded) {
      event.preventDefault();
      event.stopPropagation();
      this.close();
      this.focus();
    } else if (event.key === 'ArrowDown' && !this.locked) {
      event.preventDefault();
      this.opened = true;
      Promise.resolve().then(() =>
        this.template
          .querySelector('.select-panel input:not(:disabled)')
          ?.focus(),
      );
    }
  }
  focusOut(event) {
    if (!event.currentTarget.contains(event.relatedTarget)) this.close();
  }
  changeOption(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'change', {
        values: toggleValue(
          this.values,
          event.target.value,
          event.target.checked,
        ),
      });
  }
  changeAll(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'change', {
        values: toggleAll(this.values, this.options, event.target.checked),
      });
  }
  remove(event) {
    event.stopPropagation();
    if (this.locked) return;
    const value = event.currentTarget.dataset.value;
    const option = this.rows.find((row) => row.value === value);
    if (option?.disabled) return;
    emit(this, 'change', {
      values: toggleValue(this.values, value, false),
    });
    this.focus();
  }
  renderedCallback() {
    const all = this.template.querySelector('[data-all]');
    if (all) all.indeterminate = this.allState.mixed;
  }
  @api
  focus() {
    this.template.querySelector('[data-trigger]')?.focus();
  }
  @api
  checkValidity() {
    return !this.required || this.locked || this.chips.length > 0;
  }
  @api
  reportValidity() {
    return this.checkValidity();
  }
}
