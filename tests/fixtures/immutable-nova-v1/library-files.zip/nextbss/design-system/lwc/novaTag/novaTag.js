import { LightningElement, api } from 'lwc';
export default class NovaTag extends LightningElement {
  @api
  label = '';
  @api
  variant = 'filled';
  @api
  tone = 'category';
  @api
  libraryAppearance = '';
  get verifiedTableLabel() {
    return this.libraryAppearance === 'verified-table-label';
  }
}
