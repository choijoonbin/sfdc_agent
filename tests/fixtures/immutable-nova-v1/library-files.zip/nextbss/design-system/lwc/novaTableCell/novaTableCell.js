import { api, LightningElement } from 'lwc';
import { asText, emit } from 'c/novaNavigationUtils';
export default class NovaTableCell extends LightningElement {
  @api
  value = '';
  @api
  label = '';
  @api
  variant = 'body';
  @api
  state = '';
  @api
  disabled = false;
  @api
  align = 'left';
  @api
  slotHeight;
  @api
  headerRows = [];
  @api
  headerType = '';
  @api
  checked = false;
  get inputSlot() {
    return this.variant === 'verified-input-slot';
  }
  get verifiedHeader() {
    return ['verified-header', 'verified-empty'].includes(this.variant);
  }
  get tableHeader() {
    return this.variant === 'verified-table-header';
  }
  get cellClass() {
    if (this.inputSlot) return 'standalone-cell verified-input-slot';
    if (this.verifiedHeader)
      return `standalone-cell verified-header ${this.variant === 'verified-empty' ? 'verified-empty' : ''}`;
    if (this.tableHeader) return 'standalone-cell verified-table-header';
    return `standalone-cell align-${['left', 'center', 'right'].includes(this.align) ? this.align : 'left'} ${['header', 'status', 'empty'].includes(this.variant) ? this.variant : 'body'} ${['selected', 'disabled', 'highlight', 'expanded', 'error', 'hovered', 'info'].includes(this.state) ? this.state : ''}`;
  }
  get text() {
    return asText(this.value) || this.label;
  }
  get checkbox() {
    return ['check', 'checkbox'].includes(this.headerType);
  }
  get checkboxLabel() {
    return this.headerType === 'check' ? '모두 선택' : '행 선택';
  }
  get headers() {
    return Array.isArray(this.headerRows)
      ? this.headerRows.map((item, i) => ({
          ...item,
          id: `header-${i}`,
          label: asText(item.label),
          className: `table-header-row${item.stretch ? ' stretch-label' : ''}`,
          sorter: item.asset === 'sorter',
          info: item.asset === 'icon',
        }))
      : [];
  }
  get slotClass() {
    return this.inputSlot
      ? 'verified-cell-content'
      : [20, 24, 28, 30, 32].includes(Number(this.slotHeight))
        ? `cell-slot slot-${this.slotHeight}`
        : '';
  }
  sort(event) {
    if (!this.disabled)
      emit(this, 'sort_change', {
        label: event.currentTarget.dataset.label,
      });
  }
  select(event) {
    event.stopPropagation();
    if (!this.disabled)
      emit(this, 'selection_change', {
        checked:
          event.detail?.checked ?? event.detail?.value ?? event.target.checked,
      });
  }
}
