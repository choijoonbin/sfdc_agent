import { api, LightningElement } from 'lwc';
export default class NovaDivider extends LightningElement {
  @api
  orientation = 'horizontal';
  @api
  variant = 'full';
  @api
  lineStyle = 'solid';
  @api
  surface = 'white';
  @api
  label = '';
  @api
  dense = false;
  @api
  decorative = false;
  get role() {
    return this.decorative ? null : 'separator';
  }
  get hidden() {
    return this.decorative ? 'true' : null;
  }
  get labeled() {
    return this.orientation !== 'vertical' && Boolean(this.label);
  }
  get isDense() {
    return String(this.dense);
  }
}
