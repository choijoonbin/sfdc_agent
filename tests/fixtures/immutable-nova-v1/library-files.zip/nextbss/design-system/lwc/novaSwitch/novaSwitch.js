import { LightningElement, api } from 'lwc';
import {
  stateClass,
  isDisabled,
  isReadOnly,
  flag,
  emit,
} from 'c/novaControlUtils';
export default class NovaSwitch extends LightningElement {
  @api
  label = '';
  @api
  accessibleLabel = '';
  @api
  hideLabel = false;
  @api
  disabled = false;
  @api
  readOnly = false;
  @api
  required = false;
  @api
  size = 'large';
  @api
  state = '';
  @api
  helperText = '';
  @api
  errorMessage = '';
  @api
  name = '';
  _checked;
  @api
  get checked() {
    return (
      this._checked ??
      [
        'selected',
        'selected-hovered',
        'selected-disabled',
        'enabled-on',
        'disabled-on',
      ].includes(this.state)
    );
  }
  set checked(v) {
    this._checked = flag(v);
  }
  get rootClass() {
    return stateClass(this);
  }
  get choiceClass() {
    return (
      'choice switch' +
      (this.hideLabel ? ' hidden-choice' : '') +
      (['hovered', 'selected-hovered'].includes(this.state) ? ' hovered' : '')
    );
  }
  get labelClass() {
    return this.hideLabel ? 'choice-label hidden-label' : 'choice-label';
  }
  get locked() {
    return isDisabled(this) || isReadOnly(this);
  }
  get requiredValue() {
    return this.required || this.state === 'required';
  }
  get invalid() {
    return !!this.errorMessage || this.state === 'error';
  }
  get description() {
    return this.errorMessage || this.helperText;
  }
  get describedBy() {
    return this.description ? 'helper' : undefined;
  }
  get inputLabel() {
    return this.accessibleLabel || this.label;
  }
  renderedCallback() {
    const input = this.template.querySelector('input');
    if (input) {
      input.checked = this.checked;
    }
  }
  handleChange(event) {
    event.stopPropagation();
    if (this.locked) return;
    emit(this, 'change', {
      checked: event.target.checked,
      value: event.target.checked,
    });
  }
  @api
  focus() {
    this.template.querySelector('input')?.focus();
  }
  @api
  checkValidity() {
    return this.template.querySelector('input')?.checkValidity() ?? true;
  }
  @api
  reportValidity() {
    return this.template.querySelector('input')?.reportValidity() ?? true;
  }
}
