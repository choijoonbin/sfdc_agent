// Viewport geometry only: no global DOM lookup or shared overlay state.
export function positionFloating(
  anchor,
  panel,
  viewport,
  placement = 'bottom',
  options = {},
) {
  const gap = Math.max(0, Number(options.gap ?? 6));
  const padding = Math.max(0, Number(options.padding ?? 8));
  const width = Math.max(0, Number(panel.width ?? 0));
  const height = Math.max(0, Number(panel.height ?? 0));
  const vw = Math.max(0, Number(viewport.width ?? 0));
  const vh = Math.max(0, Number(viewport.height ?? 0));
  const left = Number(anchor.left ?? 0);
  const top = Number(anchor.top ?? 0);
  const right = Number(anchor.right ?? left + Number(anchor.width ?? 0));
  const bottom = Number(anchor.bottom ?? top + Number(anchor.height ?? 0));
  let side = ['top', 'right', 'bottom', 'left'].includes(placement)
    ? placement
    : 'bottom';
  if (
    side === 'bottom' &&
    bottom + gap + height > vh - padding &&
    top - gap - height >= padding
  )
    side = 'top';
  else if (
    side === 'top' &&
    top - gap - height < padding &&
    bottom + gap + height <= vh - padding
  )
    side = 'bottom';
  else if (
    side === 'right' &&
    right + gap + width > vw - padding &&
    left - gap - width >= padding
  )
    side = 'left';
  else if (
    side === 'left' &&
    left - gap - width < padding &&
    right + gap + width <= vw - padding
  )
    side = 'right';
  let x = (left + right - width) / 2;
  let y = (top + bottom - height) / 2;
  if (side === 'top') y = top - gap - height;
  else if (side === 'bottom') y = bottom + gap;
  else if (side === 'left') x = left - gap - width;
  else x = right + gap;
  return {
    left: Math.max(
      padding,
      Math.min(x, Math.max(padding, vw - padding - width)),
    ),
    top: Math.max(
      padding,
      Math.min(y, Math.max(padding, vh - padding - height)),
    ),
    placement: side,
  };
}
