import { LightningElement, api } from 'lwc';
import { optionsOf, nextEnabled } from 'c/novaSelectionUtils';
import { stateClass, isDisabled, isReadOnly, emit } from 'c/novaControlUtils';
let groupSequence = 0;
export default class NovaRadioGroup extends LightningElement {
  // Synthetic shadow does not isolate native radio names between component instances.
  groupId = ++groupSequence;
  get groupName() {
    return `${this.name || 'nova-radio'}-${this.groupId}`;
  }
  @api
  label = '';
  @api
  accessibleLabel = '';
  @api
  hideLabel = false;
  @api
  name = 'nova-radio';
  @api
  libraryAppearance = '';
  @api
  options = [];
  @api
  value = '';
  @api
  size = 'small';
  @api
  state = '';
  @api
  disabled = false;
  @api
  readOnly = false;
  @api
  required = false;
  @api
  orientation = 'horizontal';
  @api
  helperText = '';
  @api
  errorMessage = '';
  get rootClass() {
    return stateClass(this);
  }
  get choiceClass() {
    return (
      'choice radio' +
      (['hovered', 'selected-hovered'].includes(this.state) ? ' hovered' : '')
    );
  }
  get groupClass() {
    return this.orientation === 'vertical' ? 'choices vertical' : 'choices';
  }
  get labelClass() {
    return this.hideLabel ? 'label hidden-label' : 'label';
  }
  get requiredValue() {
    return this.required || this.state === 'required';
  }
  get locked() {
    return isDisabled(this) || isReadOnly(this);
  }
  get rows() {
    return optionsOf(this.options).map((option) => ({
      ...option,
      selected: option.value === this.value,
      disabled: this.locked || option.disabled,
    }));
  }
  get description() {
    return this.errorMessage || this.helperText;
  }
  get describedBy() {
    return this.description ? 'helper' : undefined;
  }
  get invalid() {
    return !!this.errorMessage || this.state === 'error';
  }
  handleChange(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'change', {
        value: event.target.value,
      });
  }
  handleKey(event) {
    if (
      this.locked ||
      !['ArrowDown', 'ArrowRight', 'ArrowUp', 'ArrowLeft'].includes(event.key)
    )
      return;
    event.preventDefault();
    const direction = ['ArrowDown', 'ArrowRight'].includes(event.key) ? 1 : -1;
    const rows = this.rows;
    const next = nextEnabled(
      rows,
      rows.findIndex((row) => row.value === event.target.value),
      direction,
    );
    const input = this.template.querySelectorAll('input')[next];
    if (input) {
      input.focus();
      input.checked = true;
      if (input.value !== this.value)
        emit(this, 'change', {
          value: input.value,
        });
    }
  }
  @api
  focus() {
    const inputs = [...this.template.querySelectorAll('input')];
    (
      inputs.find((input) => input.checked && !input.disabled) ||
      inputs.find((input) => !input.disabled)
    )?.focus();
  }
  @api
  checkValidity() {
    return (
      !this.requiredValue ||
      this.locked ||
      this.rows.some((row) => row.selected)
    );
  }
  @api
  reportValidity() {
    const valid = this.checkValidity();
    if (!valid)
      this.template.querySelector('input:not(:disabled)')?.reportValidity();
    return valid;
  }
}
