export function calendarDate(year, month, day) {
  const date = new Date(0);
  date.setFullYear(year, month, day);
  date.setHours(12, 0, 0, 0);
  return date;
}
export function isoDate(date) {
  return `${String(date.getFullYear()).padStart(4, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
export function datePart(value) {
  const match = /^(\d{4})[-.](\d{2})[-.](\d{2})(?:$|[ T])/.exec(
    String(value ?? ''),
  );
  if (!match) return '';
  const [, y, m, d] = match;
  if (Number(y) < 1 || Number(y) > 9999) return '';
  const formatted = `${y}-${m}-${d}`;
  return isoDate(calendarDate(Number(y), Number(m) - 1, Number(d))) ===
    formatted
    ? formatted
    : '';
}
export function timePart(value) {
  const match = /[ T]([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?$/.exec(
    String(value ?? ''),
  );
  return match ? `${match[1]}:${match[2]}:${match[3] ?? '00'}` : '00:00:00';
}
export function dateAllowed(value, min, max) {
  const date = datePart(value);
  const lower = datePart(min);
  const upper = datePart(max);
  return !!date && (!lower || date >= lower) && (!upper || date <= upper);
}
export function formatDate(value, withTime = false, placeholder = '') {
  const date = datePart(value);
  return date
    ? date.replaceAll('-', '.') + (withTime ? ` ${timePart(value)}` : '')
    : placeholder || (withTime ? 'yyyy.mm.dd 00:00:00' : 'yyyy.mm.dd');
}
export function monthDays(
  year,
  month,
  start = '',
  end = '',
  min = '',
  max = '',
) {
  const first = calendarDate(year, month, 1);
  const length = calendarDate(year, month + 1, 0).getDate();
  return Array.from(
    {
      length: Math.ceil((length + first.getDay()) / 7) * 7,
    },
    (_, i) => {
      const date = calendarDate(year, month, 1 + i - first.getDay());
      const value = isoDate(date);
      return {
        value,
        label: date.getDate(),
        selected: value === start || value === end,
        disabled: !dateAllowed(value, min, max),
        css: `day${date.getMonth() !== month ? ' outside' : ''}${end && value > start && value < end ? ' between' : ''}${value === start || value === end ? ' selected' : ''}${value === isoDate(new Date()) ? ' today' : ''}`,
      };
    },
  );
}
