import { api, LightningElement } from 'lwc';
import { emit } from 'c/novaNavigationUtils';
export default class NovaAccordionItem extends LightningElement {
  @api
  value = '';
  @api
  label = '';
  @api
  open = false;
  @api
  disabled = false;
  @api
  variant = 'primary';
  @api
  content = '';
  @api
  librarySlot = false;
  groupedOpen;
  get expanded() {
    return this.groupedOpen === undefined ? this.open : this.groupedOpen;
  }
  get expandedText() {
    return String(this.expanded);
  }
  @api
  setAccordionState(open) {
    this.groupedOpen = open;
  }
  @api
  focus() {
    this.template.querySelector('button')?.focus();
  }
  @api
  isTriggerFocused() {
    return (
      this.template.activeElement ===
      this.template.querySelector('.accordion-trigger')
    );
  }
  toggle() {
    if (this.disabled) return;
    const detail = {
      id: this.value,
      open: !this.expanded,
    };
    this.dispatchEvent(
      new CustomEvent('item_toggle', {
        detail,
        bubbles: true,
        composed: false,
      }),
    );
    emit(this, 'change', {
      open: detail.open,
      value: this.value,
    });
  }
}
