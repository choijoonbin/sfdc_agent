import { LightningElement, api } from 'lwc';
export default class NovaToolbar extends LightningElement {
  @api
  items = [];
  @api
  variant = 'control';
  @api
  orientation = 'horizontal';
  @api
  accessibleLabel = '도구 모음';
  @api
  disabled = false;
  activeId;
  openId;
  activeOption = -1;
  get controls() {
    const entries = Array.isArray(this.items)
      ? this.items.filter((item) => item && typeof item === 'object')
      : [];
    const first = entries.find(
      (item) => item.type !== 'status' && !this.disabled && !item.disabled,
    );
    return entries.map((item, index) => {
      const id = String(item.id ?? `tool-${index}`);
      const disabled = this.disabled || item.disabled === true;
      const optionsId = `nova-toolbar-options-${index}`;
      const options = (Array.isArray(item.options) ? item.options : [])
        .map((option, optionIndex) =>
          typeof option === 'object' && option !== null
            ? {
                ...option,
                value: option.value ?? option.id ?? optionIndex,
              }
            : {
                value: option,
                label: String(option),
              },
        )
        .map((option, optionIndex) => ({
          ...option,
          id: `${optionsId}-${optionIndex}`,
          index: optionIndex,
          selected: String(option.value) === String(item.value),
          active: optionIndex === this.activeOption,
        }));
      const current =
        this.activeId &&
        entries.some(
          (entry, entryIndex) =>
            String(entry.id ?? `tool-${entryIndex}`) === this.activeId &&
            !entry.disabled,
        )
          ? this.activeId
          : first
            ? String(first.id ?? `tool-${entries.indexOf(first)}`)
            : undefined;
      const expanded = !disabled && this.openId === id;
      return {
        id,
        label: String(item.label ?? ''),
        disabled,
        options,
        expanded,
        optionsId,
        controlsId: expanded ? optionsId : undefined,
        activeOptionId: expanded ? options[this.activeOption]?.id : undefined,
        valueLabel:
          options.find((option) => option.selected)?.label ??
          item.placeholder ??
          item.label ??
          '',
        isStatus: item.type === 'status',
        isSelect: item.type === 'select',
        pressed: typeof item.selected === 'boolean' ? item.selected : undefined,
        tabIndex: !disabled && current === id ? 0 : -1,
      };
    });
  }
  renderedCallback() {
    const active = this.template.querySelector(
      '.toolbar-option[data-active="true"]',
    );
    const panel = active?.parentElement;
    if (active && panel) {
      if (active.offsetTop < panel.scrollTop)
        panel.scrollTop = active.offsetTop;
      else if (
        active.offsetTop + active.offsetHeight >
        panel.scrollTop + panel.clientHeight
      )
        panel.scrollTop =
          active.offsetTop + active.offsetHeight - panel.clientHeight;
    }
  }
  handleFocus(event) {
    this.activeId = event.currentTarget.dataset.id;
  }
  handleAction(event) {
    const item = this.controls.find(
      (entry) => entry.id === event.currentTarget.dataset.id,
    );
    if (!item || item.disabled) return;
    this.dispatchEvent(
      new CustomEvent('action', {
        detail: {
          id: item.id,
          ...(item.pressed === undefined
            ? {}
            : {
                selected: !item.pressed,
              }),
        },
      }),
    );
  }
  handleToolbarKey(event) {
    if (
      event.defaultPrevented ||
      ![
        'ArrowLeft',
        'ArrowRight',
        'ArrowUp',
        'ArrowDown',
        'Home',
        'End',
      ].includes(event.key)
    )
      return;
    const vertical = this.orientation === 'vertical';
    if (
      (vertical && ['ArrowLeft', 'ArrowRight'].includes(event.key)) ||
      (!vertical && ['ArrowUp', 'ArrowDown'].includes(event.key))
    )
      return;
    const buttons = Array.from(
      this.template.querySelectorAll('.tool-control'),
    ).filter((control) => !control.disabled);
    if (!buttons.length) return;
    let index = buttons.findIndex((control) =>
      event.composedPath().includes(control),
    );
    if (index < 0) index = 0;
    if (event.key === 'Home') index = 0;
    else if (event.key === 'End') index = buttons.length - 1;
    else
      index =
        (index +
          (['ArrowLeft', 'ArrowUp'].includes(event.key) ? -1 : 1) +
          buttons.length) %
        buttons.length;
    event.preventDefault();
    this.openId = undefined;
    this.activeId = buttons[index].dataset.id;
    buttons[index].focus();
  }
  handleSelect(event) {
    const item = this.controls.find(
      (entry) => entry.id === event.currentTarget.dataset.id,
    );
    if (!item || item.disabled) return;
    if (this.openId === item.id) {
      this.openId = undefined;
      return;
    }
    this.openId = item.id;
    this.activeOption = Math.max(
      0,
      item.options.findIndex((option) => option.selected && !option.disabled),
    );
    this.ensureEnabledOption(item, 1);
  }
  ensureEnabledOption(item, delta) {
    if (!item.options.some((option) => !option.disabled)) {
      this.activeOption = -1;
      return;
    }
    for (let i = 0; i < item.options.length; i += 1) {
      if (!item.options[this.activeOption]?.disabled) return;
      this.activeOption =
        (this.activeOption + delta + item.options.length) % item.options.length;
    }
  }
  handleSelectKey(event) {
    const item = this.controls.find(
      (entry) => entry.id === event.currentTarget.dataset.id,
    );
    if (!item || item.disabled) return;
    if (event.key === 'Escape') {
      if (item.expanded) {
        event.preventDefault();
        event.stopPropagation();
        this.openId = undefined;
      }
      return;
    }
    if (event.key === 'Tab') {
      this.openId = undefined;
      return;
    }
    if (
      ['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(event.key) &&
      !item.expanded
    ) {
      event.preventDefault();
      event.stopPropagation();
      this.handleSelect(event);
      return;
    }
    if (
      !item.expanded ||
      !['ArrowDown', 'ArrowUp', 'Home', 'End', 'Enter', ' '].includes(event.key)
    )
      return;
    event.preventDefault();
    event.stopPropagation();
    if (['Enter', ' '].includes(event.key)) {
      this.choose(item, this.activeOption);
      return;
    }
    const delta = event.key === 'ArrowUp' || event.key === 'End' ? -1 : 1;
    if (event.key === 'Home') this.activeOption = 0;
    else if (event.key === 'End') this.activeOption = item.options.length - 1;
    else
      this.activeOption =
        (this.activeOption + delta + item.options.length) % item.options.length;
    this.ensureEnabledOption(item, delta);
  }
  choose(item, index) {
    const option = item.options[index];
    if (!option || option.disabled) return;
    this.openId = undefined;
    if (option.selected) return;
    this.dispatchEvent(
      new CustomEvent('change', {
        detail: {
          id: item.id,
          value: option.value,
        },
      }),
    );
  }
  handleOption(event) {
    const item = this.controls.find(
      (entry) => entry.id === event.currentTarget.dataset.id,
    );
    if (item) this.choose(item, Number(event.currentTarget.dataset.index));
  }
  retainFocus(event) {
    event.preventDefault();
  }
  handleBlur(event) {
    if (!event.currentTarget.contains(event.relatedTarget))
      this.openId = undefined;
  }
}
