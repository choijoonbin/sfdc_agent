import { LightningElement, api } from 'lwc';
import {
  normalizeActions,
  synchronizeDialog,
  isBackdropPress,
} from 'c/novaOverlayUtils';
import { focusFirst } from 'c/novaFocusUtils';
const DEFAULT_ACTIONS = [];
export default class NovaModal extends LightningElement {
  @api
  open = false;
  @api
  heading = '';
  @api
  message = '';
  @api
  accessibleLabel = '안내';
  @api
  actions;
  @api
  disabled = false;
  @api
  busy = false;
  @api
  variant = 'default';
  @api
  size = 'default';
  @api
  dismissOnBackdrop = false;
  _dismissible = true;
  @api
  get dismissible() {
    return this._dismissible;
  }
  set dismissible(value) {
    this._dismissible = value === true || value === '' || value === 'true';
  }
  get dialogRole() {
    return 'dialog';
  }
  footerAssigned = false;
  get actionItems() {
    return normalizeActions(
      this.actions,
      DEFAULT_ACTIONS,
      this.disabled || this.busy,
    );
  }
  get dialogKind() {
    return 'modal-popup';
  }
  get dialogVariant() {
    return this.variant === 'viewer'
      ? 'viewer'
      : ['full', 'fullscreen'].includes(this.size)
        ? 'full'
        : this.size === 'expanded' || this.size === 'extended'
          ? 'expanded'
          : this.variant;
  }
  get viewer() {
    return this.variant === 'viewer';
  }
  get hasHeading() {
    return Boolean(this.heading) && this.variant !== 'contents-only';
  }
  get titleReference() {
    return this.hasHeading ? 'popup-title' : undefined;
  }
  get descriptionReference() {
    return this.message ? 'popup-message' : undefined;
  }
  get dialogLabel() {
    return this.hasHeading
      ? undefined
      : this.accessibleLabel || this.heading || '안내';
  }
  get footerEmpty() {
    return !this.footerAssigned && !this.actionItems.length;
  }
  get canClose() {
    return this.dismissible;
  }
  renderedCallback() {
    synchronizeDialog(this.template.querySelector('dialog'), this.open);
  }
  disconnectedCallback() {
    this.template.querySelector('dialog')?.close();
  }
  @api
  focus() {
    const popup = this.template.querySelector('dialog');
    return focusFirst(popup, popup);
  }
  onFooterSlotChange(event) {
    this.footerAssigned = event.target
      .assignedNodes()
      .some((node) => node.nodeType !== 3 || node.textContent.trim());
  }
  requestClose(reason, actionId) {
    this.dispatchEvent(
      new CustomEvent('request_close', {
        detail: {
          reason,
          ...(actionId
            ? {
                actionId,
              }
            : {}),
        },
      }),
    );
  }
  onAction(event) {
    const action = this.actionItems.find(
      (item) => item.id === event.currentTarget.dataset.id,
    );
    if (!action || action.disabled) return;
    this.dispatchEvent(
      new CustomEvent('action', {
        detail: {
          id: action.id,
          ...(action.value === undefined
            ? {}
            : {
                value: action.value,
              }),
        },
      }),
    );
    if (action.dismiss) this.requestClose('action', action.id);
  }
  onNativeClose() {
    if (this.isConnected && this.open) this.requestClose('native-close');
  }
  onClose() {
    if (this.canClose) this.requestClose('close-button');
  }
  onCancel(event) {
    event.preventDefault();
    if (this.canClose) this.requestClose('escape');
  }
  onBackdrop(event) {
    if (this.canClose && this.dismissOnBackdrop && isBackdropPress(event, event.currentTarget))
      this.requestClose('backdrop');
  }
}
