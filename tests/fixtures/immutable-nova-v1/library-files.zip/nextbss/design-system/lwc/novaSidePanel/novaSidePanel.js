import { api, LightningElement } from 'lwc';
import { emit } from 'c/novaNavigationUtils';
import { focusFirst, trapFocus } from 'c/novaFocusUtils';
export default class NovaSidePanel extends LightningElement {
  @api
  open = false;
  @api
  modal = false;
  @api
  placement = 'right';
  @api
  label = '보조 패널';
  @api
  content = '';
  @api
  footer = '';
  @api
  dismissible = false;
  footerAssigned = false;
  wasOpen = false;
  wasModal = false;
  get footerHidden() {
    return !this.footerAssigned && !this.footer;
  }
  get modalState() {
    return this.modal ? 'true' : null;
  }
  footerChanged(event) {
    this.footerAssigned = event.target
      .assignedNodes({
        flatten: true,
      })
      .some((node) => node.nodeType === 1 || node.textContent.trim());
  }
  renderedCallback() {
    const dialog = this.template.querySelector('dialog');
    if (!dialog) return;
    if (dialog.open && this.wasModal !== this.modal) dialog.close();
    if (this.open && !dialog.open) {
      if (this.modal) dialog.showModal();
      else dialog.show();
      if (this.modal) focusFirst(this.template);
    } else if (!this.open && dialog.open) dialog.close();
    this.wasModal = this.modal;
    this.wasOpen = this.open;
  }
  disconnectedCallback() {
    this.template.querySelector('dialog')?.close();
  }
  close() {
    emit(this, 'request_close', {
      reason: 'close-button',
    });
  }
  cancel(event) {
    event.preventDefault();
    emit(this, 'request_close', {
      reason: 'escape',
    });
  }
  backdrop(event) {
    if (
      !this.modal ||
      !this.dismissible ||
      event.target !== event.currentTarget
    )
      return;
    const r = event.currentTarget.getBoundingClientRect();
    if (
      event.clientX < r.left ||
      event.clientX > r.right ||
      event.clientY < r.top ||
      event.clientY > r.bottom
    )
      emit(this, 'request_close', {
        reason: 'backdrop',
      });
  }
  keys(event) {
    if (this.modal) trapFocus(event, this.template);
    else if (event.key === 'Escape') {
      event.preventDefault();
      emit(this, 'request_close', {
        reason: 'escape',
      });
    }
  }
  @api
  focus() {
    focusFirst(this.template);
  }
}
