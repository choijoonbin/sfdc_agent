import { LightningElement, api } from 'lwc';
import { createNotificationTimer } from 'c/novaNotificationUtils';
import { normalizeActions } from 'c/novaOverlayUtils';
import { getFeedbackIcon } from 'c/novaFeedbackIcons';
export default class NovaSnackbar extends LightningElement {
  @api
  open = false;
  @api
  message = '';
  @api
  heading = '';
  @api
  tone = 'neutral';
  @api
  duration = 0;
  @api
  placement = 'inline';
  @api
  actions;
  @api
  actionLabel = '';
  @api
  actionId = 'action';
  _dismissible = true;
  @api
  get dismissible() {
    return this._dismissible;
  }
  set dismissible(value) {
    this._dismissible = value === true || value === '' || value === 'true';
  }
  @api
  disabled = false;
  _timer;
  _timerKey = '';
  _closeRequested = false;
  _hovered = false;
  _focused = false;
  get snackbar() {
    return true;
  }
  get notificationRole() {
    return ['error', 'negative'].includes(this.tone) ? 'alert' : 'status';
  }
  get actionItems() {
    return normalizeActions(
      this.actions,
      this.actionLabel
        ? [
            {
              id: this.actionId,
              label: this.actionLabel,
            },
          ]
        : [],
      this.disabled,
    );
  }
  get closePath() {
    return getFeedbackIcon('close').paths[0].d;
  }
  renderedCallback() {
    if (!this._timer)
      this._timer = createNotificationTimer(() => this.requestClose('timeout'));
    const key = this.open
      ? `${this.message}|${this.heading}|${this.tone}|${this.duration}`
      : '';
    if (key !== this._timerKey) {
      this._timer.clear();
      this._timerKey = key;
      this._closeRequested = false;
      if (key) {
        this._timer.start(this.duration);
        if (this._hovered || this._focused) this._timer.pause();
      } else {
        this._hovered = false;
        this._focused = false;
      }
    }
  }
  disconnectedCallback() {
    this._timer?.dispose();
    this._timer = undefined;
    this._timerKey = '';
  }
  requestClose(reason) {
    if (this._closeRequested || !this.open) return;
    this._closeRequested = true;
    this._timer?.clear();
    this.dispatchEvent(
      new CustomEvent('request_close', {
        detail: {
          reason,
        },
      }),
    );
  }
  handleDismiss() {
    this.requestClose('close-button');
  }
  handleAction(event) {
    const action = this.actionItems.find(
      (item) => item.id === event.currentTarget.dataset.id,
    );
    if (!action || action.disabled) return;
    this.dispatchEvent(
      new CustomEvent('action', {
        detail: {
          id: action.id,
        },
      }),
    );
    if (action.dismiss) this.requestClose('action');
  }
  pauseTimer(event) {
    if (event?.type === 'mouseenter') this._hovered = true;
    if (event?.type === 'focusin') this._focused = true;
    this._timer?.pause();
  }
  resumeTimer(event) {
    if (event?.type === 'mouseleave') this._hovered = false;
    if (event?.type === 'focusout') {
      if (event.currentTarget.contains(event.relatedTarget)) return;
      this._focused = false;
    }
    if (!this._closeRequested && !this._hovered && !this._focused)
      this._timer?.resume();
  }
}
