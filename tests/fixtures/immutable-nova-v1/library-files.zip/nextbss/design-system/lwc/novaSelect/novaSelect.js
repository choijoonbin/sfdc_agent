import { LightningElement, api } from 'lwc';
import { optionsOf, asList, nextEnabled } from 'c/novaSelectionUtils';
import {
  stateClass,
  isDisabled,
  isReadOnly,
  emit,
  safeFieldStyle,
} from 'c/novaControlUtils';
import {
  selectChevronPath,
  compactSelectChevronPath,
} from 'c/novaControlIcons';
export default class NovaSelect extends LightningElement {
  @api
  label = '';
  @api
  accessibleLabel = '';
  @api
  hideLabel = false;
  @api
  size = 'large';
  @api
  state = '';
  @api
  disabled = false;
  @api
  readOnly = false;
  @api
  required = false;
  @api
  placeholder = '';
  @api
  helperText = '';
  @api
  helperIndicator = false;
  @api
  errorMessage = '';
  @api
  widthBehavior = '';
  @api
  libraryAppearance = '';
  @api
  fieldBackground = '';
  @api
  fieldBorderColor = '';
  @api
  value = '';
  @api
  options = [];
  @api
  designOptions = [];
  @api
  selectedLabel = '';
  @api
  variant = '';
  @api
  initialOpen = false;
  opened;
  active = -1;
  query = '';
  queryAt = 0;
  scrollOption = false;
  get rootClass() {
    return stateClass(this);
  }
  get labelClass() {
    return this.hideLabel ? 'label hidden-label' : 'label';
  }
  get disabledValue() {
    return isDisabled(this);
  }
  get readonlyValue() {
    return isReadOnly(this);
  }
  get locked() {
    return this.disabledValue || this.readonlyValue;
  }
  get requiredValue() {
    return this.required || this.state === 'required';
  }
  get invalid() {
    return !!this.errorMessage || this.state === 'error';
  }
  get description() {
    return this.errorMessage || this.helperText;
  }
  get helperClass() {
    return this.helperIndicator ? 'helper masked-helper' : 'helper';
  }
  get describedBy() {
    return this.description ? 'helper' : undefined;
  }
  get inputLabel() {
    return this.accessibleLabel || this.label || '입력';
  }
  get sourceStyle() {
    return safeFieldStyle(this);
  }
  @api
  focus() {
    this.template.querySelector('button')?.focus();
  }
  @api
  checkValidity() {
    return (
      this.locked ||
      ((!this.requiredValue || this.rows.some((row) => row.selected)) &&
        !this.errorMessage)
    );
  }
  @api
  reportValidity() {
    const valid = this.checkValidity();
    if (!valid) this.focus();
    return valid;
  }
  get rows() {
    const items = optionsOf(this.options);
    return (
      items.length
        ? items
        : asList(this.designOptions)
            .filter((item) => item?.label && item?.id)
            .map((item) => ({
              label: item.label,
              value: item.id,
              disabled: true,
            }))
    ).map((option, index) => ({
      ...option,
      id: `option-${index}`,
      index,
      selected: option.value === this.value,
      disabled: this.locked || option.disabled,
      active: index === this.active,
    }));
  }
  get selectedText() {
    return (
      this.rows.find((row) => row.selected)?.label ||
      this.selectedLabel ||
      this.placeholder
    );
  }
  get expanded() {
    return !this.locked && (this.opened ?? this.initialOpen);
  }
  get controls() {
    return this.expanded ? 'options' : undefined;
  }
  get activeId() {
    return this.expanded && this.active >= 0
      ? `option-${this.active}`
      : undefined;
  }
  get selectionLabel() {
    return this.label || this.accessibleLabel || this.placeholder || '선택';
  }
  get isIconSelect() {
    return this.variant === 'icon';
  }
  get compact() {
    return this.variant === 'borderless';
  }
  get iconSize() {
    return this.compact ? 12 : 16;
  }
  get iconViewBox() {
    return this.compact ? '0 0 12 12' : '0 0 16 16';
  }
  get chevron() {
    return this.compact ? compactSelectChevronPath : selectChevronPath;
  }
  get chevronDown() {
    return this.compact
      ? 'matrix(1 0 0 -1 2.5 7.75)'
      : 'matrix(.707106769 .707106769 -.707106769 .707106769 7.949747562 1)';
  }
  get chevronUp() {
    return this.compact
      ? 'rotate(180 6 6) matrix(1 0 0 -1 2.5 7.75)'
      : 'matrix(.707106769 -.707106769 -.707106769 -.707106769 7.949737549 14.399495125)';
  }
  open() {
    if (this.locked) return;
    this.active = this.rows.findIndex((row) => row.selected && !row.disabled);
    if (this.active < 0) this.active = nextEnabled(this.rows, -1, 1);
    this.opened = true;
    this.scrollOption = true;
  }
  close() {
    this.opened = false;
    this.active = -1;
    this.query = '';
  }
  toggle() {
    this.expanded ? this.close() : this.open();
  }
  focusOut(event) {
    if (!event.currentTarget.contains(event.relatedTarget)) this.close();
  }
  retainFocus(event) {
    event.preventDefault();
  }
  choose(event) {
    this.commit(Number(event.currentTarget.dataset.index));
  }
  commit(index) {
    const option = this.rows[index];
    if (!option || option.disabled) return;
    this.close();
    if (option.value !== this.value)
      emit(this, 'change', {
        value: option.value,
      });
  }
  keydown(event) {
    if (this.locked || event.isComposing) return;
    if (event.key === 'Tab') {
      this.close();
      return;
    }
    if (event.key === 'Escape') {
      if (this.expanded) {
        event.preventDefault();
        event.stopPropagation();
        this.close();
      }
      return;
    }
    if (['Enter', ' '].includes(event.key)) {
      event.preventDefault();
      if (this.expanded && this.active >= 0) this.commit(this.active);
      else this.open();
      return;
    }
    let target = -1;
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp')
      target = nextEnabled(
        this.rows,
        this.active,
        event.key === 'ArrowDown' ? 1 : -1,
        false,
      );
    else if (event.key === 'Home') target = nextEnabled(this.rows, -1, 1);
    else if (event.key === 'End') target = nextEnabled(this.rows, -1, -1);
    else if (
      event.key.length === 1 &&
      !event.ctrlKey &&
      !event.metaKey &&
      !event.altKey
    ) {
      const now = Date.now();
      this.query =
        (now - this.queryAt < 600 ? this.query : '') +
        event.key.toLocaleLowerCase();
      this.queryAt = now;
      target = this.rows.findIndex(
        (row) =>
          !row.disabled && row.label.toLocaleLowerCase().startsWith(this.query),
      );
    }
    if (target >= 0) {
      event.preventDefault();
      this.opened = true;
      this.active = target;
      this.scrollOption = true;
    }
  }
  renderedCallback() {
    if (this.scrollOption) {
      const panel = this.template.querySelector('.select-panel'),
        option = panel?.querySelector('[data-active="true"]');
      if (option) {
        const parent = panel.getBoundingClientRect(),
          row = option.getBoundingClientRect();
        if (row.bottom > parent.bottom)
          panel.scrollTop += row.bottom - parent.bottom;
        else if (row.top < parent.top) panel.scrollTop += row.top - parent.top;
      }
      this.scrollOption = false;
    }
  }
}
