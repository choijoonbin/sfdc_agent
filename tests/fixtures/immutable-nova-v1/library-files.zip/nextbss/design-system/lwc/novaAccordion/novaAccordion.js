import { api, LightningElement } from 'lwc';
import { normalizeItems, nextIndex, emit } from 'c/novaNavigationUtils';
export default class NovaAccordion extends LightningElement {
  @api
  items = [];
  @api
  expandedIds = [];
  @api
  multiple = false;
  @api
  variant = 'primary';
  @api
  label = '접기/펼치기';
  get entries() {
    const ids = Array.isArray(this.expandedIds) ? this.expandedIds : [];
    return normalizeItems(this.items).map((item) => ({
      ...item,
      open: ids.includes(item.id),
    }));
  }
  get children() {
    return [
      ...this.template.querySelectorAll('c-nova-accordion-item'),
      ...(this.template.querySelector('slot')?.assignedElements({
        flatten: true,
      }) || []),
    ].filter((x) => typeof x.setAccordionState === 'function');
  }
  renderedCallback() {
    this.sync();
  }
  sync() {
    const ids = Array.isArray(this.expandedIds) ? this.expandedIds : [];
    for (const child of this.children)
      child.setAccordionState(ids.includes(child.value));
  }
  handleSlot() {
    this.sync();
  }
  toggle(event) {
    event.stopPropagation();
    const { id, open } = event.detail || {};
    const current = Array.isArray(this.expandedIds) ? this.expandedIds : [];
    const ids = open
      ? this.multiple
        ? [...new Set([...current, id])]
        : [id]
      : current.filter((x) => x !== id);
    emit(this, 'change', {
      expandedIds: ids,
    });
  }
  stopChange(event) {
    event.stopPropagation();
  }
  keys(event) {
    const children = this.children.filter((x) => !x.disabled);
    if (!['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) return;
    const target = children.find((child) => child.isTriggerFocused?.());
    if (!target) return;
    const at = children.indexOf(target);
    const index = nextIndex(children, at, event.key);
    if (index >= 0) {
      event.preventDefault();
      children[index].focus();
    }
  }
}
