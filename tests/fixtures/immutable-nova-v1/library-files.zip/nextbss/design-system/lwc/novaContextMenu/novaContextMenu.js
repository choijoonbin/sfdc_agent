import { api, LightningElement } from 'lwc';
import { normalizeItems, nextIndex, emit } from 'c/novaNavigationUtils';
import { positionFloating } from 'c/novaFloatingUtils';
export default class NovaContextMenu extends LightningElement {
  @api
  items = [];
  @api
  disabled = false;
  @api
  variant = 'default';
  @api
  label = '관련 작업';
  @api
  selectedId = '';
  opened = false;
  parents = [];
  anchor;
  pendingFocus = false;
  focusKey = '';
  get roots() {
    return normalizeItems(this.items, 'menu');
  }
  get currentItems() {
    let items = this.roots;
    for (const key of this.parents)
      items = items.find((x) => x.key === key)?.children || [];
    return items;
  }
  get entries() {
    return this.currentItems.map((item) => ({
      ...item,
      disabled: this.disabled || item.disabled,
      selected: item.id === this.selectedId || item.state === 'selected',
      popup: item.hasChildren ? 'menu' : null,
    }));
  }
  get submenu() {
    return this.parents.length > 0;
  }
  get expanded() {
    return String(this.opened);
  }
  get described() {
    return this.variant === 'description';
  }
  get unavailable() {
    return this.disabled || !this.roots.some((x) => !x.disabled);
  }
  connectedCallback() {
    this.outside = (event) => {
      if (this.opened && !event.composedPath().includes(this.hostElement))
        this.hide();
    };
    window.addEventListener('pointerdown', this.outside);
  }
  disconnectedCallback() {
    window.removeEventListener('pointerdown', this.outside);
  }
  renderedCallback() {
    if (!this.opened) return;
    const menu = this.template.querySelector('[role="menu"]');
    if (!menu) return;
    const anchor =
      this.anchor ||
      this.template.querySelector('[data-trigger]')?.getBoundingClientRect();
    if (anchor) {
      const at = positionFloating(
        anchor,
        menu.getBoundingClientRect(),
        {
          width: window.innerWidth,
          height: window.innerHeight,
        },
        'bottom-start',
      );
      menu.style.left = `${at.left}px`;
      menu.style.top = `${at.top}px`;
    }
    if (this.pendingFocus) {
      this.pendingFocus = false;
      const buttons = [
        ...this.template.querySelectorAll('[data-menu-item]:not([disabled])'),
      ];
      (
        buttons.find((x) => x.dataset.key === this.focusKey) ||
        buttons[0] ||
        this.template.querySelector('[data-back]')
      )?.focus();
      this.focusKey = '';
    }
  }
  toggle(event) {
    if (this.unavailable) return;
    if (this.opened) this.hide();
    else {
      this.parents = [];
      this.anchor = event.currentTarget.getBoundingClientRect();
      this.opened = true;
      this.pendingFocus = true;
    }
  }
  context(event) {
    if (this.unavailable) return;
    event.preventDefault();
    this.parents = [];
    this.anchor = {
      left: event.clientX,
      right: event.clientX,
      top: event.clientY,
      bottom: event.clientY,
      width: 0,
      height: 0,
    };
    this.opened = true;
    this.pendingFocus = true;
  }
  choose(event) {
    const item = this.entries.find(
      (x) => x.key === event.currentTarget.dataset.key,
    );
    if (!item || item.disabled) return;
    if (item.hasChildren) {
      this.parents = [...this.parents, item.key];
      this.pendingFocus = true;
      return;
    }
    emit(this, 'item_select', {
      id: item.id,
      label: item.label,
    });
    this.hide(true);
  }
  back() {
    this.parents = this.parents.slice(0, -1);
    this.pendingFocus = true;
  }
  hide(restore = false) {
    this.opened = false;
    this.parents = [];
    if (restore) this.template.querySelector('[data-trigger]')?.focus();
  }
  blur(event) {
    if (
      event.relatedTarget &&
      !this.template.contains(event.relatedTarget) &&
      !this.hostElement.contains(event.relatedTarget)
    )
      this.hide();
  }
  keys(event) {
    if (this.unavailable) return;
    if (
      (event.shiftKey && event.key === 'F10') ||
      event.key === 'ContextMenu'
    ) {
      event.preventDefault();
      this.anchor = this.hostElement.getBoundingClientRect();
      this.opened = true;
      this.parents = [];
      this.pendingFocus = true;
      return;
    }
    if (!this.opened) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      this.hide(true);
      return;
    }
    if (event.key === 'Tab') {
      this.hide();
      return;
    }
    if (event.key === 'ArrowLeft' && this.submenu) {
      event.preventDefault();
      this.back();
      return;
    }
    const buttons = [
      ...this.template.querySelectorAll('[data-menu-item]:not([disabled])'),
    ];
    const at = buttons.findIndex((x) => x === event.target);
    const next = nextIndex(buttons, at, event.key);
    if (
      next >= 0 &&
      ['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)
    ) {
      event.preventDefault();
      buttons[next].focus();
      return;
    }
    if (event.key === 'ArrowRight') {
      const item = this.entries.find((x) => x.key === event.target.dataset.key);
      if (item?.hasChildren) {
        event.preventDefault();
        this.parents = [...this.parents, item.key];
        this.pendingFocus = true;
      }
    }
  }
}
