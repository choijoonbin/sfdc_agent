export function flag(value) {
  return value === true || value === '';
}
export function isDisabled(control) {
  return (
    control.disabled ||
    ['disabled', 'selected-disabled', 'disabled-off', 'disabled-on'].includes(
      control.state,
    )
  );
}
export function isReadOnly(control) {
  return (
    control.readOnly ||
    ['read-only', 'readonly', 'readonly-hovered'].includes(control.state)
  );
}
export function stateClass(control, extra = '') {
  const classes = [
    'control',
    ['large', 'medium', 'small', 'xsmall'].includes(control.size)
      ? control.size
      : 'large',
    extra,
  ];
  if (isDisabled(control)) classes.push('disabled-state');
  else if (isReadOnly(control)) classes.push('readonly-state');
  if (control.required || control.state === 'required')
    classes.push('required-state');
  if (control.localError || control.errorMessage || control.state === 'error')
    classes.push('invalid');
  if (
    ['highlight', 'focused', 'typing', 'hovered', 'readonly-hovered'].includes(
      control.state,
    )
  )
    classes.push(control.state);
  if (/^#[0-9a-f]{6}$/i.test(control.fieldBackground || ''))
    classes.push('source-field-background');
  if (/^#[0-9a-f]{6}$/i.test(control.fieldBorderColor || ''))
    classes.push('source-field-border');
  if (control.widthBehavior === 'flexible') classes.push('flexible');
  return classes.filter(Boolean).join(' ');
}
export function emit(control, type, detail) {
  control.dispatchEvent(
    new CustomEvent(type, {
      detail,
    }),
  );
}
export function finite(value, fallback) {
  return value !== '' && value != null && Number.isFinite(Number(value))
    ? Number(value)
    : fallback;
}
export function safeFieldStyle(control) {
  const solid = /^#[0-9a-f]{6}$/i;
  return [
    solid.test(control.fieldBackground || '')
      ? `--nova-source-field-background:${control.fieldBackground}`
      : '',
    solid.test(control.fieldBorderColor || '')
      ? `--nova-source-field-border-color:${control.fieldBorderColor}`
      : '',
  ]
    .filter(Boolean)
    .join(';');
}
