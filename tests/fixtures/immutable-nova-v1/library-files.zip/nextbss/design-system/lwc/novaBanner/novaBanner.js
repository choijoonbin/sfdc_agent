import { LightningElement, api } from 'lwc';
import { getFeedbackIcon } from 'c/novaFeedbackIcons';
const ICONS = {
  default: 'bannerInfo',
  neutral: 'bell',
  blue: 'bannerBlue',
  info: 'bannerBlue',
  green: 'success',
  success: 'success',
  yellow: 'bannerYellow',
  highlight: 'bannerYellow',
  orange: 'warning',
  warning: 'warning',
  caution: 'warning',
  red: 'error',
  error: 'error',
  negative: 'error',
};
export default class NovaBanner extends LightningElement {
  @api
  label = '';
  @api
  message = '';
  @api
  tone = 'default';
  @api
  interactive = false;
  @api
  actionId;
  @api
  disabled = false;
  @api
  announcement = 'off';
  get isInteractive() {
    return this.interactive || Boolean(this.actionId);
  }
  get title() {
    return this.label || this.message;
  }
  get supportingMessage() {
    return this.label ? this.message : undefined;
  }
  get icon() {
    return getFeedbackIcon(ICONS[this.tone] || 'bell');
  }
  get arrow() {
    return getFeedbackIcon('arrow');
  }
  get statusRole() {
    return this.announcement === 'assertive'
      ? 'alert'
      : this.announcement === 'polite'
        ? 'status'
        : undefined;
  }
  handleAction() {
    if (!this.disabled)
      this.dispatchEvent(
        new CustomEvent('action', {
          detail: {
            id: this.actionId || 'primary',
          },
        }),
      );
  }
}
