import { api, LightningElement } from 'lwc';
import { emit } from 'c/novaNavigationUtils';
export default class NovaTableExpander extends LightningElement {
  @api
  expanded = false;
  @api
  disabled = false;
  @api
  label = '행 상세';
  toggle() {
    if (!this.disabled)
      emit(this, 'change', {
        expanded: !this.expanded,
      });
  }
}
