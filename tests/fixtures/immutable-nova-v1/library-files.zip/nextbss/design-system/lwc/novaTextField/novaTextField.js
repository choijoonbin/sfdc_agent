import { LightningElement, api } from 'lwc';
import { fieldIcons } from 'c/novaControlIcons';
import {
  stateClass,
  isDisabled,
  isReadOnly,
  emit,
  safeFieldStyle,
} from 'c/novaControlUtils';
export default class NovaTextField extends LightningElement {
  @api
  label = '';
  @api
  accessibleLabel = '';
  @api
  hideLabel = false;
  @api
  size = 'large';
  @api
  state = '';
  @api
  disabled = false;
  @api
  readOnly = false;
  @api
  required = false;
  @api
  placeholder = '';
  @api
  helperText = '';
  @api
  errorMessage = '';
  @api
  maxLength;
  @api
  widthBehavior = '';
  @api
  libraryAppearance = '';
  @api
  fieldBackground = '';
  @api
  fieldBorderColor = '';
  @api
  helperIndicator = false;
  @api
  name = '';
  @api
  value = '';
  @api
  type = 'text';
  @api
  variant = '';
  @api
  actionLabel = '';
  @api
  hideMaskAction = false;
  @api
  clearable = false;
  @api
  tableQuestion = false;
  @api
  tablePlaceholderMode = '';
  revealed = false;
  get rootClass() {
    return stateClass(this);
  }
  get labelClass() {
    return this.hideLabel ? 'label hidden-label' : 'label';
  }
  get disabledValue() {
    return isDisabled(this);
  }
  get readonlyValue() {
    return isReadOnly(this);
  }
  get locked() {
    return this.disabledValue || this.readonlyValue;
  }
  get requiredValue() {
    return this.required || this.state === 'required';
  }
  get invalid() {
    return !!this.errorMessage || this.state === 'error';
  }
  get description() {
    return this.errorMessage || this.helperText;
  }
  get helperClass() {
    return this.helperIndicator ||
      (this.masked && this.libraryAppearance === 'verified-field')
      ? 'helper masked-helper'
      : 'helper';
  }
  get describedBy() {
    return this.description ? 'helper' : undefined;
  }
  get inputLabel() {
    return this.accessibleLabel || this.label || '입력';
  }
  get sourceStyle() {
    return safeFieldStyle(this);
  }
  handleInput(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'input', {
        value: event.target.value,
      });
  }
  handleChange(event) {
    event.stopPropagation();
    if (!this.locked)
      emit(this, 'change', {
        value: event.target.value,
      });
  }
  @api
  focus() {
    this.template.querySelector('input,textarea')?.focus();
  }
  @api
  checkValidity() {
    const field = this.template.querySelector('input,textarea');
    field?.setCustomValidity(this.errorMessage || '');
    return field?.checkValidity() ?? true;
  }
  @api
  reportValidity() {
    const field = this.template.querySelector('input,textarea');
    field?.setCustomValidity(this.errorMessage || '');
    return field?.reportValidity() ?? true;
  }
  get verifiedTablePlaceholderMode() {
    return this.libraryAppearance === 'verified-field' &&
      !this.masked &&
      ['ending', 'clipped'].includes(this.tablePlaceholderMode)
      ? this.tablePlaceholderMode
      : undefined;
  }
  get showTablePlaceholder() {
    return this.verifiedTablePlaceholderMode && this.placeholder && !this.value;
  }
  get masked() {
    return this.variant === 'masked' || this.type === 'password';
  }
  get inputType() {
    return this.masked
      ? this.revealed
        ? 'text'
        : 'password'
      : ['text', 'email', 'tel', 'url', 'number', 'search'].includes(this.type)
        ? this.type
        : 'text';
  }
  get showMask() {
    return this.masked && !this.hideMaskAction;
  }
  get maskLabel() {
    return this.revealed ? '숨기기' : '표시';
  }
  get maskIcon() {
    return fieldIcons[this.revealed ? 'eye' : 'eye-close'];
  }
  get clearIcon() {
    return fieldIcons.clear;
  }
  get showClear() {
    return (
      (this.clearable || this.state === 'typing') &&
      !!this.value &&
      !this.locked &&
      !this.masked &&
      !this.actionLabel
    );
  }
  toggleMask() {
    if (!this.locked) this.revealed = !this.revealed;
  }
  clear() {
    if (this.locked) return;
    emit(this, 'input', {
      value: '',
    });
    emit(this, 'change', {
      value: '',
    });
    this.focus();
  }
  action() {
    if (!this.locked)
      emit(this, 'action', {
        value: this.value,
      });
  }
}
