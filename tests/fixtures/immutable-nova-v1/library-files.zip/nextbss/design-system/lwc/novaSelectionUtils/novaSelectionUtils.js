export function asList(value) {
  if (Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(value ?? '[]');
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
export function optionsOf(value) {
  const used = new Set();
  return asList(value).flatMap((option) => {
    const label = typeof option === 'string' ? option : option?.label;
    const key = typeof option === 'string' ? option : option?.value;
    if (
      typeof label !== 'string' ||
      typeof key !== 'string' ||
      !key ||
      used.has(key)
    )
      return [];
    used.add(key);
    return [
      {
        label,
        value: key,
        disabled: option?.disabled === true,
      },
    ];
  });
}
export function toggleValue(values, value, checked) {
  const next = new Set(asList(values));
  if (checked) next.add(value);
  else next.delete(value);
  return [...next];
}
export function toggleAll(values, options, checked) {
  let next = asList(values).slice();
  for (const option of optionsOf(options))
    if (!option.disabled) next = toggleValue(next, option.value, checked);
  return next;
}
export function groupState(values, options) {
  const selected = new Set(asList(values));
  const enabled = optionsOf(options).filter((option) => !option.disabled);
  const count = enabled.filter((option) => selected.has(option.value)).length;
  return {
    all: enabled.length > 0 && count === enabled.length,
    mixed: count > 0 && count < enabled.length,
    disabled: enabled.length === 0,
  };
}
export function nextEnabled(rows, index, direction, wrap = true) {
  const enabled = rows
    .map((row, i) => ({
      ...row,
      index: i,
    }))
    .filter((row) => !row.disabled);
  if (!enabled.length) return -1;
  const current = enabled.findIndex((row) => row.index === index);
  const target =
    current < 0
      ? direction < 0
        ? enabled.length - 1
        : 0
      : wrap
        ? (current + direction + enabled.length) % enabled.length
        : Math.min(enabled.length - 1, Math.max(0, current + direction));
  return enabled[target].index;
}
